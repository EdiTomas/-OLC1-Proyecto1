/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this templasymte file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aplicacion;

import Arbol.Analizador1;
import Arbol.Analizador2;
import Arbol.Nodo;
import Arbol.RecorrerAstHtml;
import Arbol.RecorrerAstUfe;
import Arbol.RecorrerAstUfe1;
import static Arbol.RecorrerAstUfe1.errorsemantico;
import static Arbol.RecorrerAstUfe1.print;
import Ent.Entorno;
import FaseCompilador1.Lexico;
import static FaseCompilador1.Lexico.listaError;
import FaseCompilador1.Sintactico;
import static FaseCompilador1.Sintactico.ErrorSintactico;
import FaseCompilador2.Parser;
import FaseCompilador2.Scaneo;
import FaseCompilador3.A_Lexico;
import FaseCompilador3.A_Sintactico;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTree;
import javax.swing.event.AncestorListener;
import javax.swing.event.CaretEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;

/**
 *
 * @author edi
 */
public final class Ventana extends javax.swing.JFrame {

    public static String resultado;
    public static String listaerror;
    public static ArrayList<JTextPane> texto = new ArrayList();
    public static int numero;
    public static File archivo;
    final StyleContext cont;
    final AttributeSet attr;
    final AttributeSet attrgreen;
    final AttributeSet attrmagenta;
    final AttributeSet attrBlack;
    final AttributeSet attrRed;
    final AttributeSet attrCeleste;
    
         PanelTab btc; 
                
  
    JTextPane editor;
    JFileChooser seleccionar = new JFileChooser();
    FileInputStream entrada;
    FileOutputStream salida;
    DefaultTreeModel modelo;
    DefaultStyledDocument doc;
    Entorno ent = new Entorno(null);

    /**
     * Creates new form Ventana
     */
    public Ventana() {
        initComponents();
       // btc = new PanelTab(Pestana, numero);
        cont = StyleContext.getDefaultStyleContext();
        attr = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.BLUE);
        attrgreen = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.GREEN);
        attrmagenta = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.MAGENTA);
        attrBlack = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.BLACK);
        attrRed = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.RED);
        attrCeleste = cont.addAttribute(cont.getEmptySet(), StyleConstants.Foreground, Color.CYAN);
        
        editor = new JTextPane();
        numero = -1;
        // Cambiamos los iconos

        DefaultTreeCellRenderer render = (DefaultTreeCellRenderer) jTree1.getCellRenderer();
        render.setLeafIcon(new ImageIcon("src/Imagenes/File.png"));
        render.setOpenIcon(new ImageIcon("src/Imagenes/3.png"));
        render.setClosedIcon(new ImageIcon("src/Imagenes/3.png"));

        Tree();

    }

    public void cambiarColores() {
        doc = new DefaultStyledDocument() {
            public void insertString(int offset, String str, AttributeSet a) throws BadLocationException {
                super.insertString(offset, str, a);

                String text = getText(0, getLength());
                int before = findLastNonWordChar(text, offset);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text, offset + str.length());
                int wordL = before;
                int wordR = before;
//attrgreen attrmagenta  attrCeleste
                while (wordR <= after) {
                    if (wordR == after || String.valueOf(text.charAt(wordR)).matches("\\W")) {
                        if (text.toLowerCase().substring(wordL, wordR).matches("(\\W)*(si|sino|mientras|var|repetir|import|return|false|true|from)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attr, false);
                        } else if (text.toLowerCase().substring(wordL, wordR).matches("(\\W)*(component|panel|text|textfield|button|list|spinner|image)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attrgreen, false);
                        } else if (text.toLowerCase().substring(wordL, wordR).matches("(\\W)*(html|head|div|body|noufe|title)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attrmagenta, false);
                        } else if (text.toLowerCase().substring(wordL, wordR).matches("(\\W)*(background|border|color|align|width|font|size|height)")) {
                            setCharacterAttributes(wordL, wordR - wordL, attrRed, false);
                        }
                        else {
                            setCharacterAttributes(wordL, wordR - wordL, attrBlack, false);
                            
                        }
                        wordL = wordR;
                    }
                    wordR++;
                }
            }
            public void remove(int offs, int len) throws BadLocationException {
                super.remove(offs, len);

                String text = getText(0, getLength());
                int before = findLastNonWordChar(text, offs);
                if (before < 0) {
                    before = 0;
                }
                int after = findFirstNonWordChar(text, offs);

                if (text.toLowerCase().substring(before, after).matches("(\\W)*(si|sino|mientras|var|repetir|import|return|false|true|from)")) {
                    setCharacterAttributes(before, after - before, attr, false);
                } else if (text.toLowerCase().substring(before, after).matches("(\\W)*(component|panel|text|textfield|button|list|spinner|image)")) {
                    setCharacterAttributes(before, after - before, attrgreen, false);

                } else if (text.toLowerCase().substring(before, after).matches("(\\W)*(html|head|div|body|noufe|title)")) {
                    setCharacterAttributes(before, after - before, attrmagenta, false);

                } else if (text.toLowerCase().substring(before, after).matches("(\\W)*(background|border|color|align|width|font|size|height)")) {
                    setCharacterAttributes(before, after - before, attrRed, false);

                }
                /*
                else if (text.toLowerCase().substring(before, after).matches("[#][//][.]*[ \\t\\n\\x0b\\r\\f]")) {
                    setCharacterAttributes(before, after - before, attrCeleste, false);

                }*/
                 else {
                    setCharacterAttributes(before, after - before, attrBlack, false);
                }
            }
        };
    }

    private int findLastNonWordChar(String text, int index) {
        while (--index >= 0) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
            
        }
        return index;
    }

    private int findFirstNonWordChar(String text, int index) {
        while (index < text.length()) {
            if (String.valueOf(text.charAt(index)).matches("\\W")) {
                break;
            }
            
            index++;
        }
        return index;
    }

    public String GuardarArchivo(File Archivo, String documento) {
        String mensaje = null;
        try {

            salida = new FileOutputStream(Archivo);
            byte[] bytxt = documento.getBytes();
            salida.write(bytxt);
            mensaje = "Archivo Guardado";
        } catch (Exception v) {
        }
        return mensaje;
    }

    public void save() {
        if (numero != -1) {
            //  archivo = new File("/home/edi/eytr");
            seleccionar.setCurrentDirectory(archivo);

            String ruta = seleccionar.getCurrentDirectory() + "/" + Pestana.getTitleAt(Pestana.getSelectedIndex());
            File arc = new File(ruta);
            if (arc.exists()) {
                arc = arc.getAbsoluteFile();
                if (archivo.getName().endsWith("html") || archivo.getName().endsWith("css") || archivo.getName().endsWith("ufe")) {
                    String Documento = texto.get(Pestana.getSelectedIndex()).getText();
                    System.out.println(texto.get(Pestana.getSelectedIndex()).getText());
                    String Mensaje = GuardarArchivo(arc, Documento);
                    Pestana.setTitleAt(Pestana.getSelectedIndex(), arc.getName());
                    if (Mensaje != null) {
                        JOptionPane.showMessageDialog(null, Mensaje);
                    } else {
                        JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                }
            } else {
                FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos", "html", "css", "ufe");
                seleccionar.setFileFilter(filtro);
                if (seleccionar.showDialog(null, "Guardar") == JFileChooser.APPROVE_OPTION) {
                    archivo = seleccionar.getSelectedFile();
                    if (archivo.getName().endsWith("html") || archivo.getName().endsWith("css") || archivo.getName().endsWith("ufe")) {
                        String Documento = texto.get(Pestana.getSelectedIndex()).getText();
                        String Mensaje = GuardarArchivo(archivo, Documento);
                        Pestana.setTitleAt(Pestana.getSelectedIndex(), archivo.getName());
                        if (Mensaje != null) {
                            JOptionPane.showMessageDialog(null, Mensaje);
                        } else {
                            JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No existe ninguna pestaña");
        }
    }

    public void saveAs() {
        if (numero != -1) {
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos", "html", "css", "ufe");
            seleccionar.setFileFilter(filtro);
            if (seleccionar.showDialog(null, "Guardar Como") == JFileChooser.APPROVE_OPTION) {
                archivo = seleccionar.getSelectedFile();
                if (archivo.getName().endsWith("html") || archivo.getName().endsWith("css") || archivo.getName().endsWith("ufe")) {
                    String Documento = texto.get(Pestana.getSelectedIndex()).getText();
                    String Mensaje = GuardarArchivo(archivo, Documento);
                    Pestana.setTitleAt(Pestana.getSelectedIndex(), archivo.getName());
                    if (Mensaje != null) {
                        JOptionPane.showMessageDialog(null, Mensaje);
                    } else {
                        JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No se guardo el Documento");
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No existe ninguna pestaña");
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Pestana = new javax.swing.JTabbedPane();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        EliminarPestañas = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        CrearArchivo = new javax.swing.JMenuItem();
        AbrirArchivo = new javax.swing.JMenuItem();
        GuardarArchivo = new javax.swing.JMenuItem();
        GuardarComo = new javax.swing.JMenuItem();
        CrearProyecto = new javax.swing.JMenuItem();
        CerrarProyecto = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        EjecutarCodigo = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        MostrarErroress = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        ManualTecnico = new javax.swing.JMenuItem();
        ManualUsuario = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle(" Usac Front End  Framework");

        Pestana.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jTabbedPane2.addTab("Consola", jScrollPane1);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jTabbedPane2.addTab("Reportes", jScrollPane2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jTabbedPane2.addTab("Tabla de Simbolos", jScrollPane3);

        javax.swing.tree.DefaultMutableTreeNode treeNode1 = new javax.swing.tree.DefaultMutableTreeNode("eytr");
        jTree1.setModel(new javax.swing.tree.DefaultTreeModel(treeNode1));
        jScrollPane4.setViewportView(jTree1);

        jTabbedPane1.addTab("Projects", jScrollPane4);

        EliminarPestañas.setText("ELiminar Pestañass");
        EliminarPestañas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarPestañasActionPerformed(evt);
            }
        });

        jMenu1.setText("Archivo");

        CrearArchivo.setText("Crear Archivo");
        CrearArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearArchivoActionPerformed(evt);
            }
        });
        jMenu1.add(CrearArchivo);

        AbrirArchivo.setText("Abrir");
        AbrirArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AbrirArchivoActionPerformed(evt);
            }
        });
        jMenu1.add(AbrirArchivo);

        GuardarArchivo.setText("Guardar Archivo");
        GuardarArchivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarArchivoActionPerformed(evt);
            }
        });
        jMenu1.add(GuardarArchivo);

        GuardarComo.setText("GuardarComo");
        GuardarComo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GuardarComoActionPerformed(evt);
            }
        });
        jMenu1.add(GuardarComo);

        CrearProyecto.setText("Crear Proyecto");
        CrearProyecto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearProyectoActionPerformed(evt);
            }
        });
        jMenu1.add(CrearProyecto);

        CerrarProyecto.setText("Cerrar Proyecto");
        jMenu1.add(CerrarProyecto);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Compilar");

        EjecutarCodigo.setText("Ejecutar");
        EjecutarCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EjecutarCodigoActionPerformed(evt);
            }
        });
        jMenu2.add(EjecutarCodigo);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Reportes");

        MostrarErroress.setText("Mostrar Reportes");
        jMenu3.add(MostrarErroress);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Ayudar");

        ManualTecnico.setText("Manual Tecnico");
        jMenu4.add(ManualTecnico);

        ManualUsuario.setText("Manual Usuario");
        jMenu4.add(ManualUsuario);

        jMenuBar1.add(jMenu4);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 823, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Pestana, javax.swing.GroupLayout.PREFERRED_SIZE, 832, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(238, 238, 238)
                        .addComponent(EliminarPestañas)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(EliminarPestañas)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Pestana, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                        .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CrearArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearArchivoActionPerformed
        this.newfile();
    }//GEN-LAST:event_CrearArchivoActionPerformed
    public void newfile() {
        try {
            JTextField NombreArchivos = new JTextField(10);
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos", "html", "css", "ufe");
            JFileChooser inputfile = new JFileChooser("/home/edi/eytr");
            inputfile.setFileFilter(filtro);
            inputfile.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            inputfile.setControlButtonsAreShown(false);
            JPanel myPanel = new JPanel();
            myPanel.add(new JLabel("NombreArchivo:"));
            myPanel.add(NombreArchivos);
            myPanel.add(new JLabel("Por favor seleccione los datos:"));
            myPanel.add(inputfile);
            myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
            JOptionPane.showConfirmDialog(null, myPanel, "New File", JOptionPane.OK_CANCEL_OPTION);
            String projname = inputfile.getSelectedFile().getPath();
            String nombre = (NombreArchivos.getText());
            if (projname == (null) || nombre.equals("")) {
                JOptionPane.showMessageDialog(null, "Por favor llene los campos");
            } else {
                archivo = new File(projname);
                if (archivo.exists()) {
                    archivo = new File(projname + "/" + nombre);
                    archivo.createNewFile();
                    this.Tree();
                    this.NuevoArchivos(nombre);
                } else {
                    JOptionPane.showMessageDialog(null, "El proyecto  no existe");
                }
            }
        } catch (Exception e) {
        }

    }

    public void NuevoArchivos(String nombre) {
        numero++;
        texto.add(editor);
        this.cambiarColores();
         btc = new PanelTab(Pestana, numero);
        LineasTexto tmpL = new LineasTexto();
        texto.set(numero, tmpL.texto);
        texto.get(numero).setDocument(doc);
        texto.get(numero).setSelectionColor(Color.RED);
        posicionPuntero(tmpL);
        JPanel tmpP = new JPanel(new BorderLayout());
        tmpP.add(tmpL, BorderLayout.WEST);
        tmpP.add(tmpL.texto, BorderLayout.CENTER);
        Pestana.addTab(nombre, new JScrollPane(tmpP));  // nombre del archivo
        Pestana.setTabComponentAt(numero, btc);
        Pestana.setBackgroundAt(numero, Color.CYAN);
    }

    private void posicionPuntero(LineasTexto lines) {
        lines.texto.addCaretListener((CaretEvent e) -> {
            int pos = e.getDot();
            int fila = 1, columna = 0;
            int ultimalinea = -1;
            String text = lines.texto.getText().replaceAll("\r", "");
            columna = pos - ultimalinea;
        }
        );
    }


    private void GuardarComoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarComoActionPerformed
        this.saveAs();
    }//GEN-LAST:event_GuardarComoActionPerformed

    private void GuardarArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GuardarArchivoActionPerformed
        this.save();
    }//GEN-LAST:event_GuardarArchivoActionPerformed

    private void AbrirArchivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AbrirArchivoActionPerformed
        try {
            this.Open();
        } catch (Exception e) {
        }

    }//GEN-LAST:event_AbrirArchivoActionPerformed

    public void Open() {
        archivo = new File("/home/edi/eytr");
        seleccionar.setCurrentDirectory(archivo);
        FileNameExtensionFilter filtro = new FileNameExtensionFilter("Archivos", "html", "css", "ufe");
        seleccionar.setFileFilter(filtro);
        if (seleccionar.showDialog(null, "Abrir") == JFileChooser.APPROVE_OPTION) {
            archivo = seleccionar.getSelectedFile();
            if (archivo.canRead()) {
                String documento = LeerArchivo(archivo.getPath());
                this.OpenFile(documento);
                Pestana.setTitleAt(numero, archivo.getName());
            }
        }
    }

    public String LeerArchivo(String ruta) {
        String temp = "";
        try {
            BufferedReader bf = new BufferedReader(new FileReader(ruta));
            String bfRead;
            while ((bfRead = bf.readLine()) != null) {
                temp = temp + bfRead + "\n";
            }
        } catch (Exception e) {
        }
        return temp;
    }
     
    public void OpenFile(String cadena) {
        numero++;
        texto.add(editor);
        this.cambiarColores();
       // PanelTab btc = new PanelTab(Pestana, numero);
        LineasTexto tmpL = new LineasTexto();
        texto.set(numero, tmpL.texto);
        texto.get(numero).setDocument(doc);
        texto.get(numero).setSelectionColor(Color.RED);
        texto.get(numero).setText(cadena);
        posicionPuntero(tmpL);
        JPanel tmpP = new JPanel(new BorderLayout());
        tmpP.add(tmpL, BorderLayout.WEST);
        tmpP.add(tmpL.texto, BorderLayout.CENTER);
        Pestana.addTab("Nueva Pestaña ", new JScrollPane(tmpP));
        Pestana.setTabComponentAt(numero, btc);
        Pestana.setBackgroundAt(numero, Color.CYAN);
    }

    private void CrearProyectoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearProyectoActionPerformed
        String nombreproyecto = JOptionPane.showInputDialog(null, "Nombre del Proyecto");
        CrearProyectos(nombreproyecto);
    }//GEN-LAST:event_CrearProyectoActionPerformed

    private void EjecutarCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EjecutarCodigoActionPerformed
        this.Ejecutar();
    }//GEN-LAST:event_EjecutarCodigoActionPerformed

    private void EliminarPestañasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarPestañasActionPerformed
       numero--;
        Pestana.remove(numero);
        
    }//GEN-LAST:event_EliminarPestañasActionPerformed

    public void Tree() {
        try {
            DefaultMutableTreeNode raiz = new DefaultMutableTreeNode("eytr");
            File dir = new File("/home/edi/eytr");
            raiz.add(CrearArbol(dir, raiz));
            modelo = new DefaultTreeModel(raiz);
            jTree1.setModel(modelo);

            jTree1.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {

                @Override
                public void valueChanged(TreeSelectionEvent tse) {
                    DefaultMutableTreeNode nodo = (DefaultMutableTreeNode) jTree1.getLastSelectedPathComponent();
                    //  DefaultMutableTreeNode nodo = (DefaultMutableTreeNode) jTree1.getSelectionModel().getLeadSelectionPath().getPathComponent(0);
                    if (nodo != null) {
                        if (nodo.isLeaf()) {   // verifica si es hoja
                            String url = "";
                            Object[] cadena = nodo.getPath();
                            int i;
                            for (i = 0; i < cadena.length; i++) {
                                url += cadena[i];
                                if (i + 1 < cadena.length) {
                                    url += File.separator;
                                }
                            }
                            String Extension[] = nodo.toString().split("\\.");
                            // aqui le indico que tipo de extension debe abrir los archivos
                            if (Extension[1].equalsIgnoreCase("ufe")) {
                                String documento = LeerArchivo("/home/edi" + File.separator + url);
                                archivo = new File("/home/edi" + File.separator + url);
        
                                OpenFile(documento);
                                Pestana.setTitleAt(numero, nodo.toString());

                            } else if (Extension[1].equalsIgnoreCase("html")) {
                                String documento = LeerArchivo("/home/edi" + File.separator + url);
                                archivo = new File("/home/edi" + File.separator + url);
                                OpenFile(documento);
                                Pestana.setTitleAt(numero, nodo.toString());

                            } else if (Extension[1].equalsIgnoreCase("css")) {
                                String documento = LeerArchivo("/home/edi" + File.separator + url);
                                archivo = new File("/home/edi" + File.separator + url);
                                OpenFile(documento);
                                Pestana.setTitleAt(numero, nodo.toString());

                            }
                        }
                        if (nodo.getLevel() == 0) { // le indico si es el primer nivel o sea la raiz
                            Tree();
                        }
                    }
                }

            });

        } catch (Exception e) {
        }

    }

    private DefaultMutableTreeNode CrearArbol(File dir, DefaultMutableTreeNode raiz) {
        File[] ficheros = dir.listFiles();
        if (ficheros == null) {
            System.out.println("No hay ficheros en el directorio especificado");
        } else {
            DefaultMutableTreeNode lista = null;
            for (File fichero : ficheros) {
                lista = new DefaultMutableTreeNode(raiz);
                if (fichero.isDirectory()) {

                    lista.setUserObject(fichero.getName());
                    lista.add(CrearArbol(fichero, lista));
                    raiz.add(lista);
                } else if (fichero.isFile()) {
                    lista.setUserObject(fichero.getName());
                    raiz.add(lista);
                }
            }
            return lista;
        }
        return null;
    }

    public void ReiniciarMemorias() {
        listaError.clear();
        listaError.trimToSize();
        ErrorSintactico.clear();
        ErrorSintactico.trimToSize();
        print.clear();
        print.trimToSize();
        resultado = "";
        listaerror = "";
        jTextArea1.setText("");
        jTextArea2.setText("");
    }

    public void Ejecutar() {

        ReiniciarMemorias();

        int pes;
        for (pes = 0; pes < Pestana.getTabCount(); pes++) {
            String[] extend = Pestana.getTitleAt(pes).split("\\.");
            if (extend[1].equals("html")) {
                Analizador1 ana = new Analizador1();
                ana.Analizar(texto.get(pes).getText(), ent);

            } else if (extend[1].equals("ufe")) {
                Analizador2 ana = new Analizador2();
                ana.Analizar(texto.get(pes).getText(), ent);

                if (listaError.isEmpty() && ErrorSintactico.isEmpty()) {
                    int i;
                    for (i = 0; i < print.size(); i++) {
                        resultado += print.get(i).Valor.toString() + "\n";
                    }
                    jTextArea1.setText(resultado);
                } else {
                    int i, j;
                    for (i = 0; i < listaError.size(); i++) {
                        listaerror += " Numero: " + (i + 1)
                                + "  tipo:     " + listaError.get(i).tipo
                                + "  lexema:   " + listaError.get(i).error
                                + "  En la fila:  " + listaError.get(i).linea
                                + "  y columna:  " + listaError.get(i).columna
                                + "  descripcion: " + listaError.get(i).Descripcion + "\n";
                    }
                    for (j = 0; j < ErrorSintactico.size(); j++) {
                        listaerror += " Numero: " + (j + 1)
                                + "  tipo:     " + ErrorSintactico.get(j).tipo
                                + "  En la fila: " + ErrorSintactico.get(j).linea
                                + "  y columna: " + ErrorSintactico.get(j).columna
                                + "  identificador:  " + ErrorSintactico.get(j).error
                                + "  descripcion:  " + ErrorSintactico.get(j).Descripcion + "\n";
                    }
                    jTextArea2.setText(listaerror);
                
                   int p;
                for (p = 0; p < errorsemantico.size(); p++) {
                        listaerror += " Numero: " + (j + 1)
                                + "  tipo:     " + errorsemantico.get(j).tipo
                                + "  En la fila: " + errorsemantico.get(j).linea
                                + "  y columna: " + errorsemantico.get(j).columna
                                + "  identificador:  " + errorsemantico.get(j).error
                                + "  descripcion:  " + errorsemantico.get(j).Descripcion + "\n";
                    }
                }

            }
            
            
            
            
        }
}

    public void CrearProyectos(String nombreProyecto) {

        try {
            archivo = new File("/home/edi/eytr");
            if (archivo.exists()) {
                archivo = new File("/home/edi/eytr/" + nombreProyecto);
                archivo.mkdir();
                archivo = new File("/home/edi/eytr/" + nombreProyecto + "/public");
                archivo.mkdir();
                archivo = new File("/home/edi/eytr/" + nombreProyecto + "/public/index.html");
                archivo.createNewFile();
                archivo = new File("/home/edi/eytr/" + nombreProyecto + "/src");
                archivo.mkdir();
                archivo = new File("/home/edi/eytr/" + nombreProyecto + "/src/App.css");
                archivo.createNewFile();
                archivo = new File("/home/edi/eytr/" + nombreProyecto + "/src/App.ufe");
                archivo.createNewFile();
                modelo.reload();
            }

        } catch (Exception e) {

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Ventana.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Ventana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AbrirArchivo;
    private javax.swing.JMenuItem CerrarProyecto;
    private javax.swing.JMenuItem CrearArchivo;
    private javax.swing.JMenuItem CrearProyecto;
    private javax.swing.JMenuItem EjecutarCodigo;
    private javax.swing.JButton EliminarPestañas;
    private javax.swing.JMenuItem GuardarArchivo;
    private javax.swing.JMenuItem GuardarComo;
    private javax.swing.JMenuItem ManualTecnico;
    private javax.swing.JMenuItem ManualUsuario;
    private javax.swing.JMenuItem MostrarErroress;
    private javax.swing.JTabbedPane Pestana;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTree jTree1;
    // End of variables declaration//GEN-END:variables
}
