/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ent;

import java.util.Hashtable;

/**
 *
 * @author edi
 */
public class Entorno {

    public Hashtable tabla;
    public Entorno anterior;

    public Entorno(Entorno anterior) {
        tabla = new Hashtable();
        this.anterior = anterior;
    }

    public void put(String s, Simbolos sim) {
        tabla.put(s, sim);

    }

    public Simbolos buscar(String s) {
        for (Entorno e = this; e != null; e = e.anterior) {
            Simbolos encontrado = (Simbolos) (e.tabla.get(s));
            if (encontrado != null) {
                return encontrado;
            }
        }
        return null;
    }
}
