/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ent;

/**
 *
 * @author edi
 */
public class Simbolos {

    public EnumTipo tipo;
    public Object valor;
    public int Columna;
    public int Fila;

    public Simbolos(EnumTipo tipo, Object valor, int Columna, int Fila) {
        this.tipo = tipo;
        this.valor = valor;
        this.Columna = Columna;
        this.Fila = Fila;
    }

    public enum EnumTipo {
        entero, doble, cadena, booleano, caracter, error, var,component
    }

}
