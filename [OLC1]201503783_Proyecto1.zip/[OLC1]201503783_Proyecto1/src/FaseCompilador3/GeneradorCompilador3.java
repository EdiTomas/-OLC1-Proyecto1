/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FaseCompilador3;

/**
 *
 * @author edi
 */
public class GeneradorCompilador3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    generarcompiladores1();
    }
    
    
    public static void generarcompiladores1() {
        try {
            String ruta = "src/FaseCompilador3/";
            String opcFlex[] = {ruta + "A_Lexico.jflex", "-d", ruta};
            jflex.Main.generate(opcFlex);

            String opcCUP[] = {"-destdir", ruta, "-parser", "A_Sintactico" ,"-symbols","simbolos1", ruta + "A_Sintactico.cup"};
            java_cup.Main.main(opcCUP);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
    
}
