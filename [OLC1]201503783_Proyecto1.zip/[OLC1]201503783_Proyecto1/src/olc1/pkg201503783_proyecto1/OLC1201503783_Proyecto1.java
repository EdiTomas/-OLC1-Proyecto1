/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olc1.pkg201503783_proyecto1;

import Aplicacion.Ventana;
import Componentes.VentanaInicial;
import java.awt.Label;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import org.jvnet.substance.SubstanceLookAndFeel;

/**
 *
 * @author edi
 */


public class OLC1201503783_Proyecto1 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     /*
      v.show();
      v.setTitle("control de notas");
      JLabel L = new JLabel("hola mundo");
      L.setBounds(10, 5, 100, 100);
      v.add(L);
      */
      
        try {
              JFrame.setDefaultLookAndFeelDecorated(true);
              JDialog.setDefaultLookAndFeelDecorated(true);
              UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
               //  SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.EmeraldDuskSkin");
       
        }catch (Exception e) {

        }
        
      /*  
        catch (ClassNotFoundException e) {

        } catch (InstantiationException e) {

        } catch (IllegalAccessException e) {

        } catch (UnsupportedLookAndFeelException e) {

        }
    */
        //    SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.EmeraldDuskSkin");
        //  SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.MagmaSkin");
        // SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.RavenSkin");
        Ventana vn = new Ventana();
        vn.show();
    }

}
