/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Componentes;

import java.util.ArrayList;

/**
 *
 * @author edi
 */
public class Selector {
   public   String id ;
   public  ArrayList<ComponenteCss>   listaAdyacencia;

    public Selector(String id, ArrayList<ComponenteCss> listaAdyacencia) {
        this.id = id;
        this.listaAdyacencia = listaAdyacencia;
    }
}
