/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Componentes;

/**
 *
 * @author edi
 */
public class AtributoLabel {
     public String id;
   public Object valor;

    public AtributoLabel() {
        this.id = "";
        this.valor = null;
 
    }
 
    public AtributoLabel(String id, Object valor) {
        this.id = id;
        this.valor = valor;
    }
}
