/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Componentes;

/**
 *
 * @author edi
 */
public class RGB {

    public int entero1;
    public int entero2;
    public int entero3;

    public RGB(int entero1, int entero2, int entero3) {
        this.entero1 = entero1;
        this.entero2 = entero2;
        this.entero3 = entero3;
    }

}
