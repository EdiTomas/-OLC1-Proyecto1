/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arbol;

import static Aplicacion.Ventana.texto;
import Ent.Entorno;
import static FaseCompilador1.Lexico.listaError;
import static FaseCompilador1.Sintactico.ErrorSintactico;
import FaseCompilador2.Parser;
import FaseCompilador2.Scaneo;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.StringReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static org.jvnet.substance.watermark.SubstanceBinaryWatermark.getName;

/**
 *
 * @author edi
 */
public class Analizador3 implements EjecutarAnalizadores{
    //import "/home/edi/eytr/USAC/src/App.css";

    @Override
    public void Analizar(String Texto, Entorno ent) {
    
        Scaneo lx = new Scaneo(new BufferedReader(new StringReader(Texto)));
        Parser sin = new Parser(lx);
        try {
            sin.parse();
        } catch (Exception ex) {
            Logger.getLogger(getName()).log(Level.SEVERE, null, ex);
        }
        if (listaError.isEmpty() && ErrorSintactico.isEmpty()) {
                Nodo raiz = sin.padre;
              //  Graficar(raiz);
                RecorrerCss css = new RecorrerCss();
                css.S(raiz, ent);
            JOptionPane.showMessageDialog(null, "La gramatica esta correcta");
        } else {
            JOptionPane.showMessageDialog(null, "La gramatica No es correcta ");
        }
    }

    @Override
    public void Graficar(Nodo raiz) {
    
     try {
            String ruta = "Arbolcss.dot";
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=TB; "
                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
            );
            bw.write(recorrerarbol(raiz) + "\n" + "}");
            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "Arbolcss.png", "Arbolcss.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
            pbuilder = new ProcessBuilder("eog", "Arbolcss.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    
    
    
    
    }

    @Override
    public String recorrerarbol(Nodo raiz) {
    String cuerpo = "";
        for (Nodo hijos : raiz.getHijos()) {

            if (hijos.getValor() != null) {
                cuerpo += "\"" + raiz.getIdNod() + "\"" + " [label=\"" + raiz.getEtiqueta() + "\"]";
                cuerpo += "\"" + hijos.getIdNod() + "\"" + " [label=\"" + hijos.getValor() + "\"]";
                cuerpo += "\"" + raiz.getIdNod() + "\" -> " + "\"" + hijos.getIdNod() + "\"";
                cuerpo += recorrerarbol(hijos);
            }
        }
        return cuerpo;
    
    
    }
    
}
