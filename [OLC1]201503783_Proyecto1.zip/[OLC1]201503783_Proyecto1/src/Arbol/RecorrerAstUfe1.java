/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arbol;

import Aplicacion.Ventana;
import static Arbol.RecorrerAstHtml.html;
import static Arbol.RecorrerAstHtml.identificador;
import static Arbol.RecorrerAstHtml.titulo;
import static Arbol.RecorrerCss.ListaCSS;
import Componentes.AtributoBoton;
import Componentes.AtributoCombobox;
import Componentes.AtributoImagenes;
import Componentes.AtributoLabel;
import Componentes.AtributoPanel;
import Componentes.AtributoSpinner;
import Componentes.Panel1;
import Componentes.RGB;
import Componentes.Selector;
import Componentes.VentanaInicial;
import Ent.Entorno;
import Ent.Simbolos;
import Reportes.ErrorSemantico;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import static javax.swing.text.StyleConstants.FontSize;
import static javax.swing.text.StyleConstants.Size;

/**
 *
 * @author edi
 */
public class RecorrerAstUfe1 {

    public VentanaInicial vntinicial;
    public static ArrayList<ErrorSemantico> errorsemantico = new ArrayList();
    public static ArrayList<Expresion> print = new ArrayList();
    public Panel1 panelprincipal = new Panel1();
    //  public LinkedList<AtributoPanel> agregarAtributos = new LinkedList();

    public RecorrerAstUfe1() {
        vntinicial = new VentanaInicial();
    }

    public void Ejecutar(Nodo Raiz, Entorno ent) {
        this.INICIO(Raiz, ent);
    }

    public void INICIO(Nodo Raiz, Entorno ent) {
        Raiz.getHijos().forEach((Nodo hijo) -> {
            switch (hijo.getEtiqueta()) {
                case "DECLARACION"://listo
                    //    this.DECLARACION(hijo, ent);
                    break;
                case "IMPORTAR":
                    //       this.IMPORTAR(hijo, ent);
                    break;
                case "ASIGNACION"://listo
                    //  this.ASIGNACION(hijo, ent);
                    break;
                case "ARREGLOS":  //listo
                    //  this.ARREGLOS(hijo, ent);
                    break;
                case "RENDER":
                    this.RENDER(hijo, ent);
                    break;
                case "DECLARACIONVECTOR": //listo
                    //  this.DECLARACIONVECTOR(hijo, ent);
                    break;
                case "ASIGNVECTOR": //listo
                    //  this.ASIGNVECTOR(hijo, ent);
                    break;
                case "COMPONENTE":
                    //    this.COMPONENTE(hijo, ent);
                    break;

                default:
                    break;
            }
        });

    }

    private void COMPONENTE(Nodo Raiz, Entorno ent) {
        this.CONTENIDO(Raiz.getHijos().get(1), ent);
    }

    private Object CONTENIDO(Nodo Raiz, Entorno ent) {
        Object componente = null;
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "SENTENCIAS":
                    this.SENTENCIAS(hijo, ent);
                    break;
                case "DECLARACION":
                    this.DECLARACION(hijo, ent);
                    break;
                case "ASIGNACION":
                    this.ASIGNACION(hijo, ent);
                    break;
                case "RETORNAR":
                    componente = this.RETONAR(hijo, ent);

                    break;
                case "IMPRIMIR":
                    this.IMPRIMIR(hijo, ent);
                    break;
                case "ARREGLOS":  //listo
                    this.ARREGLOS(hijo, ent);
                    break;
                case "DECLARACIONVECTOR": //listo
                    this.DECLARACIONVECTOR(hijo, ent);
                    break;
                case "ASIGNVECTOR": //listo
                    this.ASIGNVECTOR(hijo, ent);
                    break;

            }
        }
        return componente;
    }
    public ArrayList<Object> listacomponentes = new ArrayList();

    private void RENDER(Nodo Raiz, Entorno ent) {
        Simbolos id = ent.buscar(Raiz.getHijos().get(1).getEtiqueta());
        Simbolos pagina = ent.buscar(Raiz.getHijos().get(0).getValor());
        if (id != null && pagina != null) {

            if (id.valor.equals(Raiz.getHijos().get(1).getValor())) {
                vntinicial.show();
                Simbolos e = ent.buscar("title");
                vntinicial.setTitle(e.valor.toString());
                // aqui debemos de agregar los componentes
                Entorno local = new Entorno(ent);

                Object componente = this.CONTENIDO((Nodo) pagina.valor, local);
                if (componente != null) {
                    if (componente instanceof JPanel) {
                        vntinicial.add((JPanel) componente);
                    } else if (componente instanceof JLabel) {
                        vntinicial.add((JLabel) componente);
                    } else if (componente instanceof JTextField) {
                        vntinicial.add((JTextField) componente);
                    } else if (componente instanceof JButton) {
                        vntinicial.add((JButton) componente);
                    } else if (componente instanceof JSpinner) {
                        vntinicial.add((JSpinner) componente);
                    } else if (componente instanceof JComboBox) {
                        vntinicial.add((JComboBox) componente);
                    }
                } else {
                    for (Object a : listacomponentes) {
                        if (a instanceof JPanel) {
                            vntinicial.add((JPanel) a);
                        } else if (a instanceof JLabel) {
                            vntinicial.add((JLabel) a);
                        } else if (a instanceof JTextField) {
                            vntinicial.add((JTextField) a);
                        } else if (a instanceof JButton) {
                            vntinicial.add((JButton) a);
                        } else if (a instanceof JSpinner) {
                            vntinicial.add((JSpinner) a);
                        } else if (a instanceof JComboBox) {
                            vntinicial.add((JComboBox) a);
                        }

                    }

                }

            } else {
                System.out.println("No se encuentra disponible el nombre");
            }
        } else {

            try {
                FileWriter archivo = new FileWriter("/home/edi/Escritorio/index.html");
                PrintWriter escritura = new PrintWriter(archivo);
                escritura.println(html.get(0));
                archivo.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                ProcessBuilder pbuilder;
                pbuilder = new ProcessBuilder("run-mailcap", "/home/edi/Escritorio/index.html");
                pbuilder.redirectErrorStream(true);
                pbuilder.start();
            } catch (IOException ex) {
                Logger.getLogger(Ventana.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("No existe este metodo");
            return;
        }
    }

    private Object RETONAR(Nodo Raiz, Entorno ent) {
        return this.CONTENIDORETORNO(Raiz.getHijos().get(0), ent);
    }

    private Object CONTENIDORETORNO(Nodo Raiz, Entorno ent) {
        Object componente = null;
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "PANEL":
                    componente = (this.PANEL(hijo, ent));
                    break;
                case "TEXT":
                    componente = (this.TEXT(hijo, ent));
                    break;
                case "TEXTFIELD":
                    componente = (this.TEXTFIELD(hijo, ent));
                    break;
                case "BUTTON":
                    componente = (this.BUTTON(hijo, ent));
                    break;
                case "LIST":
                    componente = (this.ComboList(hijo, ent));
                    break;
                case "SPINNER":
                    componente = (this.SPINNER(hijo, ent));
                    break;
                case "IMAGE":
                    componente = (this.IMAGE(hijo, ent));
                    break;
                case "RETORNARID":
                    componente = this.RETORNARID(hijo, ent);
                    break;
            }
        }

        return componente;

    }

    private JPanel PANEL(Nodo Raiz, Entorno ent) {
        JPanel nuevopaneles = new JPanel();
        LinkedList<AtributoPanel> atributospaneles = null;
        JPanel cuerpopanel = new JPanel();
        ArrayList<Object> listapanel = null;

        for (Nodo hijos : Raiz.getHijos()) {
            switch (hijos.getEtiqueta()) {
                case "LISTATRIBUTOSPANEL":
                    atributospaneles = this.LISTATRIBUTOSPANEL(hijos, ent);
                    break;
                case "CUERPOPANEL":
                    listapanel = this.CUERPOPANEL(hijos, ent);

                    break;
            }
        }

        int i;
        int x = 0;
        int y = 0;
        int width = 0;
        int height = 0;
        for (i = 0; i < atributospaneles.size(); i++) {
            if (atributospaneles.get(i).id.equalsIgnoreCase("id")) {
                nuevopaneles.setName(atributospaneles.get(i).valor.toString());
            } else if (atributospaneles.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(atributospaneles.get(i).valor.toString());
            } else if (atributospaneles.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(atributospaneles.get(i).valor.toString());
            } else if (atributospaneles.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(atributospaneles.get(i).valor.toString());
            } else if (atributospaneles.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(atributospaneles.get(i).valor.toString());
            } else if (atributospaneles.get(i).id.equalsIgnoreCase("color")) {

                switch (atributospaneles.get(i).valor.toString().toLowerCase()) {
                    case "blue":
                        nuevopaneles.setBackground(Color.BLUE);
                        break;
                    case "yellow":
                        nuevopaneles.setBackground(Color.YELLOW);
                        break;
                    case "red":
                        nuevopaneles.setBackground(Color.red);
                        break;
                    case "gray":
                        nuevopaneles.setBackground(Color.GRAY);
                        break;
                    case "green":
                        nuevopaneles.setBackground(Color.green);
                        break;
                    case "black":
                        nuevopaneles.setBackground(Color.BLACK);
                        break;
                    case "pink":
                        nuevopaneles.setBackground(Color.pink);
                        break;
                    case "orange":
                        nuevopaneles.setBackground(Color.ORANGE);
                        break;
                    default:
                        break;
                }

            } else if (atributospaneles.get(i).id.equalsIgnoreCase("border")) {
                nuevopaneles.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0),
                        Integer.parseInt(atributospaneles.get(i).valor.toString())));
                //javax.swing.

            } else if (atributospaneles.get(i).id.equalsIgnoreCase("classname")) {
              
                
                if (atributospaneles.get(i).valor.toString().contains(" ")) {
                    String cadena[] = atributospaneles.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                nuevopaneles.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                nuevopaneles.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        nuevopaneles.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        nuevopaneles.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        nuevopaneles.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        nuevopaneles.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        nuevopaneles.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        nuevopaneles.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        nuevopaneles.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        nuevopaneles.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        nuevopaneles.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        nuevopaneles.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        nuevopaneles.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        nuevopaneles.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        nuevopaneles.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        nuevopaneles.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                nuevopaneles.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                nuevopaneles.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        nuevopaneles.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        nuevopaneles.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        nuevopaneles.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        nuevopaneles.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        nuevopaneles.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        nuevopaneles.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        nuevopaneles.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        nuevopaneles.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        nuevopaneles.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        nuevopaneles.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        nuevopaneles.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        nuevopaneles.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        nuevopaneles.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        nuevopaneles.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                nuevopaneles.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    nuevopaneles.setFont(fuente);
                                    nuevopaneles.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = atributospaneles.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            nuevopaneles.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            nuevopaneles.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    nuevopaneles.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    nuevopaneles.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    nuevopaneles.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    nuevopaneles.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    nuevopaneles.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    nuevopaneles.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    nuevopaneles.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    nuevopaneles.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    nuevopaneles.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    nuevopaneles.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    nuevopaneles.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    nuevopaneles.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    nuevopaneles.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    nuevopaneles.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            nuevopaneles.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            nuevopaneles.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    nuevopaneles.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    nuevopaneles.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    nuevopaneles.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    nuevopaneles.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    nuevopaneles.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    nuevopaneles.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    nuevopaneles.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    nuevopaneles.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    nuevopaneles.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    nuevopaneles.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    nuevopaneles.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    nuevopaneles.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    nuevopaneles.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    nuevopaneles.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            nuevopaneles.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                nuevopaneles.setFont(fuente);
                                nuevopaneles.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }

            }// fin del clasename
        }
        nuevopaneles.setLayout(null);
        nuevopaneles.setBounds(x, y, width, height);
        if (listapanel != null) {
            int j;
            for (j = 0; j < listapanel.size(); j++) {
                if (listapanel.get(j) != null) {
                    if (listapanel.get(j) instanceof JPanel) {
                        nuevopaneles.add((JPanel) listapanel.get(j));
                    } else if (listapanel.get(j) instanceof JLabel) {
                        nuevopaneles.add((JLabel) listapanel.get(j));
                    } else if (listapanel.get(j) instanceof JTextField) {
                        nuevopaneles.add((JTextField) listapanel.get(j));
                    } else if (listapanel.get(j) instanceof JButton) {
                        nuevopaneles.add((JButton) listapanel.get(j));
                    } else if (listapanel.get(j) instanceof JSpinner) {
                        nuevopaneles.add((JSpinner) listapanel.get(j));
                    } else if (listapanel.get(j) instanceof JComboBox) {
                        nuevopaneles.add((JComboBox) listapanel.get(j));
                    }

                }

            }

        }

        return nuevopaneles;
    }

    private LinkedList<AtributoPanel> LISTATRIBUTOSPANEL(Nodo Raiz, Entorno ent) {
        LinkedList<AtributoPanel> atributospaneles = new LinkedList();
        for (Nodo hijos : Raiz.getHijos()) {
            atributospaneles.add(this.ATRIBUTOTEXT(hijos, ent));
        }
        return atributospaneles;
    }

    private ArrayList<Object> CUERPOPANEL(Nodo Raiz, Entorno ent) {
        // aqui agregamos los componentes para el panel
        ArrayList<Object> cuerpopanel = new ArrayList();
        for (Nodo hijos : Raiz.getHijos()) {
            switch (hijos.getEtiqueta()) {
                case "PANEL":
                    cuerpopanel.add(this.PANEL(hijos, ent));
                    break;
                case "TEXT":
                    cuerpopanel.add(this.TEXT(hijos, ent));
                    break;
                case "TEXTFIELD":
                    cuerpopanel.add(this.TEXTFIELD(hijos, ent));
                    break;
                case "BUTTON":
                    cuerpopanel.add(this.BUTTON(hijos, ent));
                    break;
                case "LIST":
                    cuerpopanel.add(this.ComboList(hijos, ent));
                    break;
                case "SPINNER":
                    cuerpopanel.add(this.SPINNER(hijos, ent));
                    break;
                case "IMAGE":
                    cuerpopanel.add(this.IMAGE(hijos, ent));
                    break;
                case "ADDPANEL":
                    cuerpopanel.add(this.ADDPANEL(hijos, ent));
                    break;
            }
        }
        return cuerpopanel;
    }

    private Object RETORNARID(Nodo Raiz, Entorno ent) {
        Simbolos sim1 = ent.buscar(Raiz.getHijos().get(0).getValor());

        if (sim1 != null) {
            Entorno local = new Entorno(ent);
            Object componente = this.CONTENIDO1((Nodo) sim1.valor, local);

            if (componente == null) {
                for (Object a : listacomponentes) {
                    componente = a;
                }
            }
            return componente;

        } else {
            System.out.println("----------------Error no existe los panales------------------");
            return null;
        }
    }

    private Object ADDPANEL(Nodo Raiz, Entorno ent) {
        Simbolos sim1 = ent.buscar(Raiz.getHijos().get(0).getValor());

        if (sim1 != null) {
            //     return this.CONTENIDO1((Nodo) sim1.valor, ent);
            Entorno local = new Entorno(ent);
            Object componente = this.CONTENIDO1((Nodo) sim1.valor, local);

            if (componente == null) {

                for (Object a : listacomponentes) {
                    componente = a;
                }

            }
            return componente;

        } else {
            System.out.println("----------------Error no existe los panales------------------");
            return null;
        }
    }

    private Object CONTENIDO1(Nodo Raiz, Entorno ent) {
        Object contenedor = null;
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "RETORNAR":
                    contenedor = this.RETORNAR1(hijo, ent);
                    break;

                case "SENTENCIAS":
                    //   contenedor = this.RETORNAR1(hijo, ent);
                    this.SENTENCIAS(hijo, ent);
                    break;
                case "IMPRIMIR":
                    //   contenedor = this.RETORNAR1(hijo, ent);
                    this.IMPRIMIR(hijo, ent);
                    break;

                case "DECLARACION":
                    this.DECLARACION(hijo, ent);
                    break;
                case "ASIGNACION":
                    this.ASIGNACION(hijo, ent);
                    break;
                case "ARREGLOS":  //listo
                    this.ARREGLOS(hijo, ent);
                    break;
                case "DECLARACIONVECTOR": //listo
                    this.DECLARACIONVECTOR(hijo, ent);
                    break;
                case "ASIGNVECTOR": //listo
                    this.ASIGNVECTOR(hijo, ent);
                    break;
            }
        }
        return contenedor;
    }

    private Object RETORNAR1(Nodo Raiz, Entorno ent) {
        return CONTENIDORETORNO1(Raiz.getHijos().get(0), ent);
    }

    private Object CONTENIDORETORNO1(Nodo Raiz, Entorno ent) {

        Object componente = null;
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "PANEL":

                    componente = this.PANEL(hijo, ent);
                    break;
                case "TEXT":
                    componente = (this.TEXT(hijo, ent));

                    break;
                case "TEXTFIELD":
                    componente = (this.TEXTFIELD(hijo, ent));
                    break;
                case "BUTTON":
                    componente = (this.BUTTON(hijo, ent));

                    break;
                case "LIST":
                    componente = (this.ComboList(hijo, ent));

                    break;
                case "SPINNER":
                    componente = (this.SPINNER(hijo, ent));

                    break;
                case "IMAGE":
                    componente = (this.IMAGE(hijo, ent));
                    break;
                case "RETORNARID":
                    componente = (this.RETORNARID(hijo, ent));
                    break;
            }

        }

        return componente;
    }

    //*****************************************Labels*****************************************************************   
    private AtributoPanel ATRIBUTOTEXT(Nodo Raiz, Entorno ent) {
        return new AtributoPanel(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
    }

    private JLabel TEXT(Nodo Raiz, Entorno ent) {

        JLabel etiqueta = new JLabel();
        ArrayList<AtributoLabel> listlabel = null;
        etiqueta.setText(CUERPOTEXTO(Raiz.getHijos().get(1), ent));
        listlabel = LISTATRIBUTOSLABEL(Raiz.getHijos().get(0), ent);

        int i;
        int x = 0, y = 0, height = 0, width = 0;

        for (i = 0; i < listlabel.size(); i++) {
            if (listlabel.get(i).id.equalsIgnoreCase("id")) {

            } else if (listlabel.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listlabel.get(i).valor.toString());
            } else if (listlabel.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listlabel.get(i).valor.toString());
            } else if (listlabel.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listlabel.get(i).valor.toString());
            } else if (listlabel.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listlabel.get(i).valor.toString());
            } else if (listlabel.get(i).id.equalsIgnoreCase("color")) {
            } else if (listlabel.get(i).id.equalsIgnoreCase("border")) {

            } else if (listlabel.get(i).id.equalsIgnoreCase("classname")) {
            
            if (listlabel.get(i).valor.toString().contains(" ")) {
                    String cadena[] = listlabel.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                etiqueta.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                etiqueta.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        etiqueta.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        etiqueta.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        etiqueta.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        etiqueta.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        etiqueta.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        etiqueta.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        etiqueta.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        etiqueta.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        etiqueta.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        etiqueta.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        etiqueta.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        etiqueta.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        etiqueta.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        etiqueta.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                etiqueta.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                etiqueta.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        etiqueta.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        etiqueta.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        etiqueta.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        etiqueta.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        etiqueta.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        etiqueta.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        etiqueta.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        etiqueta.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        etiqueta.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        etiqueta.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        etiqueta.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        etiqueta.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        etiqueta.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        etiqueta.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                etiqueta.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    etiqueta.setFont(fuente);
                                    etiqueta.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = listlabel.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            etiqueta.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            etiqueta.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    etiqueta.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    etiqueta.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    etiqueta.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    etiqueta.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    etiqueta.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    etiqueta.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    etiqueta.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    etiqueta.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    etiqueta.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    etiqueta.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    etiqueta.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    etiqueta.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    etiqueta.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    etiqueta.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            etiqueta.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            etiqueta.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    etiqueta.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    etiqueta.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    etiqueta.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    etiqueta.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    etiqueta.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    etiqueta.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    etiqueta.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    etiqueta.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    etiqueta.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    etiqueta.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    etiqueta.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    etiqueta.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    etiqueta.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    etiqueta.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            etiqueta.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                etiqueta.setFont(fuente);
                                etiqueta.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }
 }
        }
        etiqueta.setBounds(x, y, width, height);

        return etiqueta;
    }

    private ArrayList<AtributoLabel> LISTATRIBUTOSLABEL(Nodo Raiz, Entorno ent) {
        ArrayList<AtributoLabel> listlabel = new ArrayList();
        for (Nodo hijo : Raiz.getHijos()) {
            listlabel.add(ATRIBUTOLABEL(hijo, ent));
        }
        return listlabel;
    }

    private AtributoLabel ATRIBUTOLABEL(Nodo Raiz, Entorno ent) {
        return new AtributoLabel(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
    }

    private String CUERPOTEXTO(Nodo Raiz, Entorno ent) {
        String cadena = "";
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "VALOR":
                    Expresion resultado = this.VAL(hijo, ent);
                    if (resultado.tipo == Simbolos.EnumTipo.error) {
                        return null;
                    }
                    cadena = resultado.Valor.toString();
                    break;
                case "LISTAID":
                    cadena = this.LISTAID(hijo, ent);
                    break;
            }
        }

        return cadena;
    }

    private Expresion VAL(Nodo Raiz, Entorno ent) {
        return this.VALOR(Raiz.getHijos().get(0), ent);
    }

    private String LISTAID(Nodo Raiz, Entorno ent) {
        String cadena = "";
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "id":
                    cadena += hijo.getValor() + " ";
                    break;
                case "decimal":
                    cadena += hijo.getValor() + " ";
                    break;
                case "entero":
                    cadena += hijo.getValor() + " ";
                    break;
                case "coma":
                    cadena += hijo.getValor() + " ";
                    break;
                case "puntoycoma":
                    cadena += hijo.getValor() + " ";
                    break;
            }
        }
        return cadena;
    }

    //*************************TextFIeld*******************************************
    private JTextField TEXTFIELD(Nodo Raiz, Entorno ent) {
        JTextField texto = new JTextField();
        ArrayList<AtributoLabel> listtexto = null;
        texto.setText(CUERPOTEXTO(Raiz.getHijos().get(1), ent));
        listtexto = LISTATRIBUTOSLABEL(Raiz.getHijos().get(0), ent);

        int i;
        int x = 0, y = 0, height = 0, width = 0;

        for (i = 0; i < listtexto.size(); i++) {
            if (listtexto.get(i).id.equalsIgnoreCase("id")) {

            } else if (listtexto.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listtexto.get(i).valor.toString());
            } else if (listtexto.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listtexto.get(i).valor.toString());
            } else if (listtexto.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listtexto.get(i).valor.toString());
            } else if (listtexto.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listtexto.get(i).valor.toString());
            } else if (listtexto.get(i).id.equalsIgnoreCase("color")) {
                
            } else if (listtexto.get(i).id.equalsIgnoreCase("border")) {

            } else if (listtexto.get(i).id.equalsIgnoreCase("classname")) {
                     
             if (listtexto.get(i).valor.toString().contains(" ")) {
                    String cadena[] = listtexto.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                texto.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                texto.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        texto.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        texto.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        texto.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        texto.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        texto.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        texto.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        texto.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        texto.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        texto.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        texto.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        texto.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        texto.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        texto.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        texto.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                texto.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                texto.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        texto.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        texto.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        texto.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        texto.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        texto.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        texto.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        texto.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        texto.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        texto.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        texto.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        texto.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        texto.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        texto.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        texto.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                texto.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    texto.setFont(fuente);
                                    texto.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = listtexto.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            texto.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            texto.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    texto.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    texto.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    texto.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    texto.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    texto.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    texto.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    texto.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    texto.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    texto.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    texto.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    texto.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    texto.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    texto.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    texto.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            texto.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            texto.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    texto.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    texto.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    texto.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    texto.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    texto.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    texto.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    texto.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    texto.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    texto.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    texto.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    texto.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    texto.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    texto.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    texto.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            texto.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                texto.setFont(fuente);
                                texto.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }
                        
                
                
                
                
                
      }
        }
        texto.setBounds(x, y, width, height);

        return texto;
    }

    //*************************Button************************************************
    private JButton BUTTON(Nodo Raiz, Entorno ent) {
        JButton boton = new JButton();
        ArrayList<AtributoBoton> listboton = null;
        boton.setText(CUERPOBOTON(Raiz.getHijos().get(1), ent));
        listboton = LISTATRIBUTOSBOTON(Raiz.getHijos().get(0), ent);

        int i;
        int x = 0, y = 0, height = 0, width = 0;

        for (i = 0; i < listboton.size(); i++) {
            if (listboton.get(i).id.equalsIgnoreCase("id")) {

            } else if (listboton.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listboton.get(i).valor.toString());
            } else if (listboton.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listboton.get(i).valor.toString());
            } else if (listboton.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listboton.get(i).valor.toString());
            } else if (listboton.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listboton.get(i).valor.toString());
            } else if (listboton.get(i).id.equalsIgnoreCase("color")) {

            } else if (listboton.get(i).id.equalsIgnoreCase("border")) {

            } else if (listboton.get(i).id.equalsIgnoreCase("classname")) {

                 if (listboton.get(i).valor.toString().contains(" ")) {
                    String cadena[] = listboton.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                boton.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                boton.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        boton.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        boton.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        boton.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        boton.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        boton.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        boton.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        boton.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        boton.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        boton.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        boton.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        boton.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        boton.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        boton.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        boton.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                boton.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                boton.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        boton.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        boton.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        boton.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        boton.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        boton.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        boton.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        boton.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        boton.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        boton.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        boton.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        boton.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        boton.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        boton.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        boton.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                boton.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    boton.setFont(fuente);
                                    boton.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = listboton.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            boton.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            boton.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    boton.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    boton.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    boton.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    boton.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    boton.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    boton.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    boton.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    boton.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    boton.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    boton.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    boton.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    boton.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    boton.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    boton.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            boton.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            boton.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    boton.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    boton.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    boton.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    boton.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    boton.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    boton.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    boton.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    boton.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    boton.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    boton.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    boton.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    boton.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    boton.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    boton.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            boton.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                boton.setFont(fuente);
                                boton.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }
    
                
                
                
                
                
                

            } else if (listboton.get(i).id.equalsIgnoreCase("onclick")) {

                String mensaje = this.ONCLICK((Nodo) listboton.get(i).valor, ent);

                boton.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent ae) {
                        JOptionPane.showMessageDialog(null, mensaje);
                    }
                });
            }
        }
        boton.setBounds(x, y, width, height);

        return boton;
    }

    private String ONCLICK(Nodo Raiz, Entorno ent) {
        String cadena = "";
        Expresion resultado = this.VALOR(Raiz.getHijos().get(0), ent);
        if (resultado.tipo == Simbolos.EnumTipo.error) {
            return null;
        }
        cadena = resultado.Valor.toString();
        return cadena;
    }

    private String CUERPOBOTON(Nodo Raiz, Entorno ent) {
        String cadena = "";
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "VALOR":
                    Expresion resultado = this.VAL(hijo, ent);
                    if (resultado.tipo == Simbolos.EnumTipo.error) {
                        return null;
                    }
                    cadena = resultado.Valor.toString();
                    break;
            }
        }
        return cadena;
    }

    private ArrayList<AtributoBoton> LISTATRIBUTOSBOTON(Nodo Raiz, Entorno ent) {
        ArrayList<AtributoBoton> listboton = new ArrayList();
        for (Nodo hijo : Raiz.getHijos()) {
            listboton.add(ATRIBUTOBOTON(hijo, ent));
        }
        return listboton;
    }

    private AtributoBoton ATRIBUTOBOTON(Nodo Raiz, Entorno ent) {

        if (Raiz.getHijos().get(1).getEtiqueta().equals("ONCLICK")) {
            return new AtributoBoton(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1));
        } else {
            return new AtributoBoton(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
        }
    }

//******************SPINNER*******************************************************
    private JSpinner SPINNER(Nodo Raiz, Entorno ent) {
        JSpinner espiner = new JSpinner();
        SpinnerNumberModel modeloSpinner;

        ArrayList<AtributoSpinner> listspinner = null;
        int i;
        int x = 0, y = 0, height = 0, width = 0, max = 0, min = 0, defecto = 0;
        Expresion resultado = OPERACION_ARITMETICA(Raiz.getHijos().get(1), ent);
        if (resultado.tipo == Simbolos.EnumTipo.error) {
            System.out.println("No funciona el JSPINNER");
            return null;
        }
        defecto = Integer.parseInt(resultado.Valor.toString());
        listspinner = LISTATRIBUTOSPINNER(Raiz.getHijos().get(0), ent);
        for (i = 0; i < listspinner.size(); i++) {
            if (listspinner.get(i).id.equalsIgnoreCase("id")) {

            } else if (listspinner.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("max")) {
                max = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("min")) {
                min = Integer.parseInt(listspinner.get(i).valor.toString());
            } else if (listspinner.get(i).id.equalsIgnoreCase("color")) {

            } else if (listspinner.get(i).id.equalsIgnoreCase("border")) {

            } else if (listspinner.get(i).id.equalsIgnoreCase("classname")) {

                    if (listspinner.get(i).valor.toString().contains(" ")) {
                    String cadena[] = listspinner.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                espiner.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                espiner.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        espiner.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        espiner.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        espiner.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        espiner.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        espiner.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        espiner.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        espiner.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        espiner.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        espiner.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        espiner.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        espiner.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        espiner.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        espiner.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        espiner.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                espiner.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                espiner.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        espiner.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        espiner.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        espiner.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        espiner.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        espiner.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        espiner.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        espiner.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        espiner.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        espiner.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        espiner.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        espiner.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        espiner.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        espiner.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        espiner.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                espiner.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    espiner.setFont(fuente);
                                    espiner.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = listspinner.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            espiner.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            espiner.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    espiner.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    espiner.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    espiner.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    espiner.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    espiner.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    espiner.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    espiner.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    espiner.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    espiner.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    espiner.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    espiner.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    espiner.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    espiner.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    espiner.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            espiner.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            espiner.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    espiner.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    espiner.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    espiner.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    espiner.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    espiner.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    espiner.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    espiner.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    espiner.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    espiner.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    espiner.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    espiner.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    espiner.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    espiner.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    espiner.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            espiner.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                espiner.setFont(fuente);
                                espiner.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }
    
                
                
                
                
                
            }
        }

        // modeloSpinner.setMaximum(max);
        // modeloSpinner.setMinimum(min);
        // modeloSpinner.setValue(defecto);
        modeloSpinner = new SpinnerNumberModel(defecto, min, max, 1);
        espiner.setModel(modeloSpinner);
        espiner.setBounds(x, y, width, height);

        return espiner;
    }

    private ArrayList<AtributoSpinner> LISTATRIBUTOSPINNER(Nodo Raiz, Entorno ent) {
        ArrayList<AtributoSpinner> listaSpinner = new ArrayList();
        for (Nodo hijo : Raiz.getHijos()) {
            listaSpinner.add(ATRIBUTOSPINNER(hijo, ent));
        }
        return listaSpinner;
    }

    private AtributoSpinner ATRIBUTOSPINNER(Nodo Raiz, Entorno ent) {

        return new AtributoSpinner(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
    }

//********************************COMBOBOX*****************************************
    private JComboBox ComboList(Nodo Raiz, Entorno ent) {
        JComboBox combo = null;

        ArrayList<AtributoCombobox> listcombo = null;
        combo = CUERPOLIST(Raiz.getHijos().get(1), ent);

        listcombo = LISTATRIBUTOCOMBO(Raiz.getHijos().get(0), ent);

        int i;
        int x = 0, y = 0, height = 0, width = 0;

        for (i = 0; i < listcombo.size(); i++) {
            if (listcombo.get(i).id.equalsIgnoreCase("id")) {

            } else if (listcombo.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listcombo.get(i).valor.toString());
            } else if (listcombo.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listcombo.get(i).valor.toString());
            } else if (listcombo.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listcombo.get(i).valor.toString());
            } else if (listcombo.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listcombo.get(i).valor.toString());
            } else if (listcombo.get(i).id.equalsIgnoreCase("color")) {
            } else if (listcombo.get(i).id.equalsIgnoreCase("border")) {

            } else if (listcombo.get(i).id.equalsIgnoreCase("classname")) {

                     if (listcombo.get(i).valor.toString().contains(" ")) {
                    String cadena[] = listcombo.get(i).valor.toString().split(" ");
                    int a, b, c;
                    int he = 0, wid = 0;
                    int tam = 0;
                    String estiloletra = "";

                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (b != cadena.length) {
                                if (cadena[b].equals(ListaCSS.get(a).get(b).id)) {
                                    for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                        if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                                Color colores = null;
                                                int grosor = 0;
                                                if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                        colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                    } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                        switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                            case "blue":
                                                                colores = Color.BLUE;
                                                                break;
                                                            case "yellow":
                                                                colores = Color.YELLOW;
                                                                break;
                                                            case "red":
                                                                colores = Color.RED;
                                                                break;
                                                            case "gray":
                                                                colores = Color.GRAY;
                                                                break;
                                                            case "green":
                                                                colores = Color.green;
                                                                break;
                                                            case "black":
                                                                colores = Color.black;
                                                                break;
                                                            case "pink":
                                                                colores = Color.PINK;
                                                                break;
                                                            case "orange":
                                                                colores = Color.ORANGE;
                                                                break;
                                                            case "white":
                                                                colores = Color.white;
                                                                break;
                                                            case "magenta":
                                                                colores = Color.MAGENTA;
                                                                break;
                                                            case "cyan":
                                                                colores = Color.cyan;
                                                                break;
                                                            case "darkgray":
                                                                colores = Color.darkGray;
                                                                break;
                                                            case "light_gray":
                                                                colores = Color.LIGHT_GRAY;
                                                                break;
                                                            case "lightgray":
                                                                colores = Color.lightGray;
                                                                break;

                                                            default:
                                                                break;
                                                        }
                                                    } else {
                                                        RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                        colores = new Color(color.entero1, color.entero2, color.entero3);

                                                    }

                                                } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                    grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                                }
                                                combo.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                            }  // si es verdadero

                                        } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                combo.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        combo.setBackground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        combo.setBackground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        combo.setBackground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        combo.setBackground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        combo.setBackground(Color.green);
                                                        break;
                                                    case "black":

                                                        combo.setBackground(Color.black);

                                                        break;
                                                    case "pink":
                                                        combo.setBackground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        combo.setBackground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        combo.setBackground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        combo.setBackground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        combo.setBackground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        combo.setBackground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        combo.setBackground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        combo.setBackground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                combo.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();

                                        } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                combo.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                            } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                    case "blue":
                                                        combo.setForeground(Color.BLUE);
                                                        break;
                                                    case "yellow":
                                                        combo.setForeground(Color.YELLOW);

                                                        break;
                                                    case "red":
                                                        combo.setForeground(Color.RED);

                                                        break;
                                                    case "gray":
                                                        combo.setForeground(Color.GRAY);

                                                        break;
                                                    case "green":

                                                        combo.setForeground(Color.green);
                                                        break;
                                                    case "black":

                                                        combo.setForeground(Color.black);

                                                        break;
                                                    case "pink":
                                                        combo.setForeground(Color.pink);
                                                        break;
                                                    case "orange":
                                                        combo.setForeground(Color.ORANGE);
                                                        break;
                                                    case "white":
                                                        combo.setForeground(Color.white);

                                                        break;
                                                    case "magenta":
                                                        combo.setForeground(Color.MAGENTA);

                                                        break;
                                                    case "cyan":
                                                        combo.setForeground(Color.CYAN);
                                                        break;
                                                    case "darkgray":
                                                        combo.setForeground(Color.darkGray);
                                                        break;
                                                    case "light_gray":
                                                        combo.setForeground(Color.LIGHT_GRAY);
                                                        break;
                                                    case "lightgray":
                                                        combo.setForeground(Color.lightGray);
                                                        break;

                                                    default:
                                                        break;

                                                }

                                            } else {
                                                RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                combo.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                            }

                                        } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                            tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                        }
                                        // aqui se coloca los componentes
                                    }
                                    Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                    combo.setFont(fuente);
                                    combo.setSize(he, wid);

                                }
                            }

                        }
                        //  ListaCSS.get(z).size()
                    }

                } else {

                    String encadenado = listcombo.get(i).valor.toString();
                    int a, b, c;
                    int tam = 0;
                    String estiloletra = "";

                    int he = 0, wid = 0;
                    for (a = 0; a < ListaCSS.size(); a++) {
                        for (b = 0; b < ListaCSS.get(a).size(); b++) {

                            if (encadenado.equals(ListaCSS.get(a).get(b).id)) {
                                for (c = 0; c < ListaCSS.get(a).get(b).listaAdyacencia.size(); c++) {
                                    if ("border".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        System.out.println(" crack sskskskskksksksks");
                                        if ("true".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString())) {
                                            Color colores = null;
                                            int grosor = 0;

                                            if ("border-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                                    colores = (Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));
                                                } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                                    switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {
                                                        case "blue":
                                                            colores = Color.BLUE;
                                                            break;
                                                        case "yellow":
                                                            colores = Color.YELLOW;
                                                            break;
                                                        case "red":
                                                            colores = Color.RED;
                                                            break;
                                                        case "gray":
                                                            colores = Color.GRAY;
                                                            break;
                                                        case "green":
                                                            colores = Color.green;
                                                            break;
                                                        case "black":
                                                            colores = Color.black;
                                                            break;
                                                        case "pink":
                                                            colores = Color.PINK;
                                                            break;
                                                        case "orange":
                                                            colores = Color.ORANGE;
                                                            break;
                                                        case "white":
                                                            colores = Color.white;
                                                            break;
                                                        case "magenta":
                                                            colores = Color.MAGENTA;
                                                            break;
                                                        case "cyan":
                                                            colores = Color.cyan;
                                                            break;
                                                        case "darkgray":
                                                            colores = Color.darkGray;
                                                            break;
                                                        case "light_gray":
                                                            colores = Color.LIGHT_GRAY;
                                                            break;
                                                        case "lightgray":
                                                            colores = Color.lightGray;
                                                            break;

                                                        default:
                                                            break;
                                                    }
                                                } else {
                                                    RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                                    colores = new Color(color.entero1, color.entero2, color.entero3);

                                                }

                                            } else if ("border-width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                                grosor = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                            }
                                            combo.setBorder(BorderFactory.createLineBorder(colores, grosor));

                                        }  // si es verdadero

                                    } else if ("width".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        wid = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("height".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        he = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());

                                    } else if ("background".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            combo.setBackground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    combo.setBackground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    combo.setBackground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    combo.setBackground(Color.RED);

                                                    break;
                                                case "gray":
                                                    combo.setBackground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    combo.setBackground(Color.green);
                                                    break;
                                                case "black":

                                                    combo.setBackground(Color.black);

                                                    break;
                                                case "pink":
                                                    combo.setBackground(Color.pink);
                                                    break;
                                                case "orange":
                                                    combo.setBackground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    combo.setBackground(Color.white);

                                                    break;
                                                case "magenta":
                                                    combo.setBackground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    combo.setBackground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    combo.setBackground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    combo.setBackground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    combo.setBackground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            combo.setBackground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        estiloletra = ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString();
                                    } else if ("align".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                    } else if ("font-color".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {

                                        if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("hex")) {
                                            combo.setForeground(Color.decode(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString()));

                                        } else if (ListaCSS.get(a).get(b).listaAdyacencia.get(c).Etiqueta.equals("id")) {
                                            switch (ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString().toLowerCase()) {

                                                case "blue":
                                                    combo.setForeground(Color.BLUE);
                                                    break;
                                                case "yellow":
                                                    combo.setForeground(Color.YELLOW);

                                                    break;
                                                case "red":
                                                    combo.setForeground(Color.RED);

                                                    break;
                                                case "gray":
                                                    combo.setForeground(Color.GRAY);

                                                    break;
                                                case "green":

                                                    combo.setForeground(Color.green);
                                                    break;
                                                case "black":

                                                    combo.setForeground(Color.black);

                                                    break;
                                                case "pink":
                                                    combo.setForeground(Color.pink);
                                                    break;
                                                case "orange":
                                                    combo.setForeground(Color.ORANGE);
                                                    break;
                                                case "white":
                                                    combo.setForeground(Color.white);

                                                    break;
                                                case "magenta":
                                                    combo.setForeground(Color.MAGENTA);

                                                    break;
                                                case "cyan":
                                                    combo.setForeground(Color.CYAN);
                                                    break;
                                                case "darkgray":
                                                    combo.setForeground(Color.darkGray);
                                                    break;
                                                case "light_gray":
                                                    combo.setForeground(Color.LIGHT_GRAY);
                                                    break;
                                                case "lightgray":
                                                    combo.setForeground(Color.lightGray);
                                                    break;

                                                default:
                                                    break;

                                            }

                                        } else {
                                            RGB color = (RGB) ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor;
                                            combo.setForeground(new Color(color.entero1, color.entero2, color.entero3));

                                        }

                                    } else if ("font-size".equalsIgnoreCase(ListaCSS.get(a).get(b).listaAdyacencia.get(c).id)) {
                                        tam = Integer.parseInt(ListaCSS.get(a).get(b).listaAdyacencia.get(c).valor.toString());
                                    }

                                }
                                Font fuente = new Font(estiloletra, Font.ITALIC, tam);
                                combo.setFont(fuente);
                                combo.setSize(he, wid);

                            }

                        }
                        //  ListaCSS.get(z).size()
                    }
                }
    
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            }
        }
        combo.setBounds(x, y, width, height);
        return combo;
    }

    private ArrayList<AtributoCombobox> LISTATRIBUTOCOMBO(Nodo Raiz, Entorno ent) {
        ArrayList<AtributoCombobox> listacombo = new ArrayList();
        for (Nodo hijo : Raiz.getHijos()) {
            listacombo.add(ATRIBUTOCOMBO(hijo, ent));
        }
        return listacombo;
    }

    private AtributoCombobox ATRIBUTOCOMBO(Nodo Raiz, Entorno ent) {
        return new AtributoCombobox(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
    }

    private JComboBox CUERPOLIST(Nodo Raiz, Entorno ent) {
        ArrayList<String> lista = null;
        JComboBox combo = new JComboBox();
        int defecto = 0;
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "ELEM":
                    lista = this.ELEM(hijo, ent);
                    break;
                case "DEFAULT":
                    defecto = Integer.parseInt(this.DEFAULT(hijo, ent));
                    break;
            }
        }

        int i;
        for (i = 0; i < lista.size(); i++) {
            if (lista.get(i) != null) {
                combo.addItem(lista.get(i));
            }

        }
        combo.setSelectedIndex(defecto);
        return combo;
    }

    private ArrayList<String> ELEM(Nodo Raiz, Entorno ent) {
        ArrayList<String> list = null;
        list = this.CUERPOELEMENTOS(Raiz.getHijos().get(0), ent);
        return list;
    }

    private String DEFAULT(Nodo Raiz, Entorno ent) {
        return Raiz.getHijos().get(0).getValor();
    }

    private ArrayList<String> CUERPOELEMENTOS(Nodo Raiz, Entorno ent) {

        String cadena = "";
        ArrayList<String> combo = new ArrayList();
        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "cadena":
                    cadena = hijo.getValor();
                    combo.add(cadena);
                    break;
                case "VALOR":
                    Expresion resultado = this.VAL(hijo, ent);
                    if (resultado.tipo == Simbolos.EnumTipo.error) {

                        return null;
                    }
                    cadena = resultado.Valor.toString();
                    combo.add(cadena);

                    break;
            }
        }
        return combo;
    }
//****************************Imagen*********************************************

    private JLabel IMAGE(Nodo Raiz, Entorno ent) {
        //Image imagen;
        ImageIcon imagen;
        Icon icono;
        ArrayList<AtributoImagenes> listaimagenes = null;
        JLabel dibujo = new JLabel();
        ;
        listaimagenes = LISTAIMAGENES(Raiz.getHijos().get(0), ent);
        int i;
        int x = 0, y = 0, height = 0, width = 0;
        String nombreImagen = "";
        for (i = 0; i < listaimagenes.size(); i++) {
            if (listaimagenes.get(i).id.equalsIgnoreCase("id")) {

            } else if (listaimagenes.get(i).id.equalsIgnoreCase("x")) {
                x = Integer.parseInt(listaimagenes.get(i).valor.toString());
            } else if (listaimagenes.get(i).id.equalsIgnoreCase("y")) {
                y = Integer.parseInt(listaimagenes.get(i).valor.toString());
            } else if (listaimagenes.get(i).id.equalsIgnoreCase("height")) {
                height = Integer.parseInt(listaimagenes.get(i).valor.toString());
            } else if (listaimagenes.get(i).id.equalsIgnoreCase("width")) {
                width = Integer.parseInt(listaimagenes.get(i).valor.toString());
            } else if (listaimagenes.get(i).id.equalsIgnoreCase("src")) {
                nombreImagen = listaimagenes.get(i).valor.toString();
            } else if (listaimagenes.get(i).id.equalsIgnoreCase("border")) { } 
              else if (listaimagenes.get(i).id.equalsIgnoreCase("classname")) {}   /// pendiente

        }
        dibujo.setBounds(x, y, height, width);
        imagen = new ImageIcon(nombreImagen);
        icono = new ImageIcon(imagen.getImage().getScaledInstance(dibujo.getWidth(), dibujo.getHeight(), Image.SCALE_DEFAULT));
        dibujo.setIcon(imagen);
        return dibujo;
    }

    private ArrayList<AtributoImagenes> LISTAIMAGENES(Nodo Raiz, Entorno ent) {
        ArrayList<AtributoImagenes> listaimagenes = new ArrayList();
        Raiz.getHijos().forEach((hijo) -> {
            listaimagenes.add(ATRIBUTOIMAGENES(hijo, ent));
        });
        return listaimagenes;
    }

    private AtributoImagenes ATRIBUTOIMAGENES(Nodo Raiz, Entorno ent) {

        return new AtributoImagenes(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor());
    }

//*************************************************************************
    private void ASIGNVECTOR(Nodo Raiz, Entorno ent) {
        Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
        String id = VECTORVALORASIGNACION(Raiz.getHijos().get(0), ent);
        if (Simbolos.EnumTipo.error == resultado.tipo) {
            System.out.println("Error no se permite");
            return;
        }
        Simbolos sim = ent.buscar(id);
        if (sim != null) {
            if (null != resultado.tipo) {
                switch (resultado.tipo) {
                    case entero: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case cadena: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case caracter: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case booleano: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case doble: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    default:
                        System.out.println("error en el simbolo");
                        break;
                }
            }
        }

    }

    private void DECLARACIONVECTOR(Nodo Raiz, Entorno ent) {
        this.DEVECTORVALOR(Raiz.getHijos().get(1), ent);
    }

    private void DEVECTORVALOR(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        int tam = Integer.parseInt(resultado.Valor.toString());
        int i;
        for (i = 0; i <= tam; i++) {
            Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.var, null, Raiz.getColumna(), Raiz.getFila());
            ent.put(id + "[" + i + "]", nuevosimbolo);
        }
    }

    private Expresion EXPARREGLO(Nodo Raiz, Entorno ent) {

        switch (Raiz.getEtiqueta()) {
            case "id":
                Simbolos sim = ent.buscar(Raiz.getValor());
                return new Expresion(sim.tipo, sim.valor);
            case "entero":
                return new Expresion(Simbolos.EnumTipo.entero, Raiz.getValor());
            case "mas":
                Expresion a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                Expresion b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) + Integer.parseInt(b.Valor.toString()));
                }
            case "menos":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) - Integer.parseInt(b.Valor.toString()));
                }
            case "por":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) * Integer.parseInt(b.Valor.toString()));
                }
            case "div":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    if (Integer.parseInt(b.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + a.tipo + " / " + b.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) / Integer.parseInt(b.Valor.toString()));
                }
            case "umenos":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                if (a.tipo == Simbolos.EnumTipo.entero) {
                    int c = -Integer.parseInt(a.Valor.toString());
                    return new Expresion(Simbolos.EnumTipo.entero, c);
                }

        }
        return new Expresion(Simbolos.EnumTipo.error, "error");
    }

    public void DECLARACION(Nodo Raiz, Entorno ent) {
        this.LISTASIGNACIONES(Raiz.getHijos().get(1), ent);
    }

    public void LISTASIGNACIONES(Nodo Raiz, Entorno ent) {
        this.ASIGNAR(Raiz.getHijos().get(0), ent);
    }

    public void ASIGNAR(Nodo Raiz, Entorno ent) {

        switch (Raiz.getHijos().size()) {
            case 1:
                String id1 = Raiz.getHijos().get(0).getValor();
                Simbolos nu = new Simbolos(Simbolos.EnumTipo.var, null, Raiz.getColumna(), Raiz.getFila());
                ent.put(id1, nu);

                break;

            case 2:

                Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
                String id = Raiz.getHijos().get(0).getValor();

                if (Simbolos.EnumTipo.error == resultado.tipo) {
                    System.out.println("Error no se permite");
                    ErrorSemantico er = new ErrorSemantico("error Semantico", resultado.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la asignacion");
                    errorsemantico.add(er);

                    return;
                }

                if (null != resultado.tipo) {
                    switch (resultado.tipo) {
                        case entero: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case cadena: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case caracter: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case booleano: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case doble: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        default:
                            break;
                    }
                }
        }

    }

    public Expresion VALOR(Nodo Raiz, Entorno ent) {
        //     System.out.println("Error no se permite");

        switch (Raiz.getEtiqueta()) {
            case "cadena":
                return new Expresion(Simbolos.EnumTipo.cadena, Raiz.getValor());

            case "entero":
                return new Expresion(Simbolos.EnumTipo.entero, Raiz.getValor());

            case "decimal":
                return new Expresion(Simbolos.EnumTipo.doble, Raiz.getValor());

            case "caracter":
                return new Expresion(Simbolos.EnumTipo.caracter, Raiz.getValor());

            case "verdadero":
                return new Expresion(Simbolos.EnumTipo.booleano, Raiz.getValor());

            case "falso":
                return new Expresion(Simbolos.EnumTipo.booleano, Raiz.getValor());

            case "id":
                Simbolos sim = ent.buscar(Raiz.getValor());
                if (sim != null) {
                    if (sim.valor != null) {
                        return new Expresion(sim.tipo, sim.valor);
                    } else {
                        ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "el valor el nulo");
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "error");
                    }

                } else {

                    ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "el id no existe");
                    errorsemantico.add(er);

                    return new Expresion(Simbolos.EnumTipo.error, "error");

                }

            case "mas":
                Expresion hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                Expresion hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {

                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) + Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) + Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.booleano && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.booleano) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a + b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a + b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a + b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a + b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                }
                System.out.println();

                ErrorSemantico er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta: " + hijoIzquierdo.tipo + " mas " + hijoDerecho.tipo);
                errorsemantico.add(er);

                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "menos":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);
                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) - Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a - b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a - b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a - b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a - b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) - Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }

                System.out.println("operacion incorrecta: " + hijoIzquierdo.tipo + " menos " + hijoDerecho.tipo);

                er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta: " + hijoIzquierdo.tipo + " menos " + hijoDerecho.tipo);
                errorsemantico.add(er);

                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "por":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);
                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) * Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a * b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a * b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a * b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a * b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) * Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }

                System.out.println("operacion incorrecta: " + hijoIzquierdo.tipo + " * " + hijoDerecho.tipo);

                er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta: " + hijoIzquierdo.tipo + " ṕor " + hijoDerecho.tipo);
                errorsemantico.add(er);

                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "div":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    if (Double.parseDouble(hijoDerecho.Valor.toString()) == 0) {

                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    if (Integer.parseInt(hijoDerecho.Valor.toString()) == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) / Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    if (Integer.parseInt(hijoDerecho.Valor.toString()) == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    if (Double.parseDouble(hijoDerecho.Valor.toString()) == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    if (b == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }

                    int total = a / b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    int total = a / b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    if (b == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    double total = a / b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    double total = a / b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        errorsemantico.add(er);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    int total = Character.getNumericValue(a) / Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "potencia":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    double a = Double.parseDouble(hijoIzquierdo.Valor.toString());
                    double b = Double.parseDouble(hijoDerecho.Valor.toString());
                    double c = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, c);

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);

                }
                er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion  " + hijoIzquierdo.tipo + " pow " + hijoDerecho.Valor);
                errorsemantico.add(er);
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "umenos":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);

                if (null != hijoIzquierdo.tipo) {
                    switch (hijoIzquierdo.tipo) {
                        case doble: {
                            double a = -Double.parseDouble(hijoIzquierdo.Valor.toString());
                            return new Expresion(Simbolos.EnumTipo.entero, a);
                        }
                        case entero: {
                            int a = -Integer.parseInt(hijoIzquierdo.Valor.toString());
                            return new Expresion(Simbolos.EnumTipo.entero, a);
                        }
                        case caracter: {
                            char a = hijoIzquierdo.Valor.toString().charAt(0);
                            double total = -a;
                            return new Expresion(Simbolos.EnumTipo.entero, total);
                        }
                        default:
                            break;
                    }
                }
                er = new ErrorSemantico("error Semantico", "Operaciones", Raiz.getFila(), Raiz.getColumna(), "operacion incorrecta division entre cero: " + hijoIzquierdo.tipo);
                errorsemantico.add(er);
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "VECTORVALOR":
                return VECTORVALOR(Raiz, ent);

        }
        return new Expresion(Simbolos.EnumTipo.error, "@error");
    }

    private Expresion VECTORVALOR(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        int i = Integer.parseInt(resultado.Valor.toString());
        Simbolos sim = ent.buscar(id + "[" + i + "]");
        if (sim != null) {
            return new Expresion(sim.tipo, sim.valor);
        } else {
            ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "no existe el id");
            errorsemantico.add(er);
        }
        return new Expresion(Simbolos.EnumTipo.error, "@error");
    }

    public void IMPRIMIR(Nodo Raiz, Entorno ent) {

        Expresion resultado = VALOR(Raiz.getHijos().get(0), ent);
        if (resultado.tipo != Simbolos.EnumTipo.error) {
            System.out.println(resultado.Valor);

            ErrorSemantico er = new ErrorSemantico("error Semantico", resultado.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en invalido en imprimir");
            errorsemantico.add(er);
            print.add(resultado);
        }

    }

    public void ASIGNACION(Nodo Raiz, Entorno ent) {

        Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
        if (Simbolos.EnumTipo.error == resultado.tipo) {
            ErrorSemantico er = new ErrorSemantico("error Semantico", resultado.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la asignacion");
            errorsemantico.add(er);

            return;
        }

        String id = Raiz.getHijos().get(0).getValor();
        Simbolos sim = ent.buscar(id);
        if (sim != null) {
            if (null != resultado.tipo) {
                switch (resultado.tipo) {
                    case entero: {
                        //    Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        //  ent.put(id, nuevo);
                        sim.valor = resultado.Valor;

                        break;
                    }
                    case cadena: {
                        //  Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        //  ent.put(id, nuevo);
                        sim.valor = resultado.Valor;

                        break;
                    }
                    case caracter: {
                        //   Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        // ent.put(id, nuevo);
                        sim.valor = resultado.Valor;

                        break;
                    }
                    case booleano: {
                        // Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        // ent.put(id, nuevo);
                        sim.valor = resultado.Valor;

                        break;
                    }
                    case doble: {
                        // Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        // ent.put(id, nuevo);
                        sim.valor = resultado.Valor;
                        break;
                    }
                    default:
                        ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "no existe el simbolo");
                        errorsemantico.add(er);

                        break;
                }
            }
        } else {
            ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "no existe el simbolo");
            errorsemantico.add(er);

        }

    }

    public void ARREGLOS(Nodo Raiz, Entorno ent) {
        this.ASIGNARARREGLO1(Raiz.getHijos().get(1), ent);

    }

    public ArrayList<Expresion> LISTEXP(Nodo Raiz, Entorno ent) {
        ArrayList<Expresion> lista = new ArrayList();
        Raiz.getHijos().forEach((Nodo hijo) -> {
            lista.add(this.VALOR(hijo, ent));
        });
        return lista;
    }

    private void ASIGNARARREGLO1(Nodo Raiz, Entorno ent) {

        ArrayList<Expresion> lista = LISTEXP(Raiz.getHijos().get(1), ent);
        String id = Raiz.getHijos().get(0).getValor();
        int i;
        for (i = 0; i < lista.size(); i++) {
            if (Simbolos.EnumTipo.error == lista.get(i).tipo) {
                ErrorSemantico er = new ErrorSemantico("error Semantico", lista.get(i).Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la asignacion");
                errorsemantico.add(er);

                return;
            }

            if (null != lista.get(i).tipo) {
                switch (lista.get(i).tipo) {
                    case entero: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.entero, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case cadena: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.cadena, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case caracter: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.caracter, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case booleano: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.booleano, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case doble: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.doble, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                }
            }
        }

    }

    private String VECTORVALORASIGNACION(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        return id + "[" + resultado.Valor.toString() + "]";
    }

    public void SENTENCIAS(Nodo Raiz, Entorno ent) {

        Raiz.getHijos().forEach((hijo) -> {

            switch (hijo.getEtiqueta()) {
                case "SI":
                    this.SI(hijo, ent);
                    break;
                case "REPETIR":
                    this.REPETIR(hijo, ent);
                    break;
                case "MIENTRAS":
                    this.MIENTRAS(hijo, ent);
                    break;
            }

        });

    }

    public void SI(Nodo Raiz, Entorno ent) {
        switch (Raiz.getHijos().size()) {
            case 2:
                Expresion condicion = this.CONDICION(Raiz.getHijos().get(0), ent);
                if (condicion.tipo == Simbolos.EnumTipo.error) {
                    System.out.println("error en la condicion");
                    ErrorSemantico er = new ErrorSemantico("error Semantico", condicion.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la condicion no es valido");
                    errorsemantico.add(er);

                    return;
                }
                boolean cod = Boolean.parseBoolean(condicion.Valor.toString());
                Nodo inst = Raiz.getHijos().get(1);
                if (cod) {
                    Entorno local = new Entorno(ent);
                    this.L_INSTRUCCIONES(inst, local);
                }
                break;
            case 3:

                if (Raiz.getHijos().get(2).getEtiqueta().equals("SINOSI")) {

                    condicion = this.CONDICION(Raiz.getHijos().get(0), ent);
                    cod = Boolean.parseBoolean(condicion.Valor.toString());
                    inst = Raiz.getHijos().get(1);
                    if (cod) {
                        Entorno local = new Entorno(ent);
                        this.L_INSTRUCCIONES(inst, local);
                        return;
                    }
                    Entorno local = new Entorno(ent);
                    this.SINOSI(Raiz.getHijos().get(2), local);

                } else {
                    condicion = this.CONDICION(Raiz.getHijos().get(0), ent);
                    cod = Boolean.parseBoolean(condicion.Valor.toString());
                    Nodo hijoelse = Raiz.getHijos().get(2);
                    if (cod) {
                        Entorno local = new Entorno(ent);
                        this.L_INSTRUCCIONES(Raiz.getHijos().get(1), local);
                    } else {
                        Entorno local = new Entorno(ent);
                        this.SINO(hijoelse, local);
                    }
                }
                break;
            case 4:

                condicion = this.CONDICION(Raiz.getHijos().get(0), ent);
                cod = Boolean.parseBoolean(condicion.Valor.toString());
                inst = Raiz.getHijos().get(1);
                boolean verificar = false;
                if (cod) {
                    Entorno local = new Entorno(ent);
                    this.L_INSTRUCCIONES(inst, local);
                } else {

                    Entorno local = new Entorno(ent);
                    verificar = this.SINOSI(Raiz.getHijos().get(2), local);

                }

                if (verificar == false) {
                    Entorno local1 = new Entorno(ent);
                    this.SINO(Raiz.getHijos().get(3), local1);

                }
                break;
            default:
                break;
        }
    }

    private void L_INSTRUCCIONES(Nodo Raiz, Entorno ent) {

        for (Nodo hijos : Raiz.getHijos()) {
            if (hijos.getEtiqueta().equals("IMPRIMIR")) {
                this.IMPRIMIR(hijos, ent);
            } else if (hijos.getEtiqueta().equals("SENTENCIAS")) {
                this.SENTENCIAS(hijos, ent);
            } else if (hijos.getEtiqueta().equals("DECLARACIONVECTOR")) {
                this.SI(hijos, ent);
            } else if (hijos.getEtiqueta().equals("MIENTRAS")) {
                this.MIENTRAS(hijos, ent);
            } else if (hijos.getEtiqueta().equals("ASIGNACION")) {
                this.ASIGNACION(hijos, ent);
            } else if (hijos.getEtiqueta().equals("ARREGLO")) {
                this.ARREGLOS(hijos, ent);
            } else if (hijos.getEtiqueta().equals("ASIGNVECTOR")) {
                this.ASIGNVECTOR(hijos, ent);
            } else if (hijos.getEtiqueta().equals("RETORNAR")) {
                listacomponentes.add(this.RETONAR(hijos, ent));
            }

        }

    }

    private Expresion CONDICION(Nodo Raiz, Entorno ent) {

        return this.CONDICIONES(Raiz.getHijos().get(0), ent);

    }

    private Expresion CONDICIONES(Nodo Raiz, Entorno ent) {
        switch (Raiz.getEtiqueta()) {
            case "or":
                Expresion a = CONDICIONES(Raiz.getHijos().get(0), ent);
                Expresion b = CONDICIONES(Raiz.getHijos().get(1), ent);
                System.out.println("" + a.Valor);
                if (Boolean.parseBoolean(a.Valor.toString()) || Boolean.parseBoolean(b.Valor.toString())) {
                    boolean result = true;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                } else {
                    boolean result = false;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                }
            case "and":
                a = CONDICIONES(Raiz.getHijos().get(0), ent);
                b = CONDICIONES(Raiz.getHijos().get(1), ent);

                if (Boolean.parseBoolean(a.Valor.toString()) && Boolean.parseBoolean(b.Valor.toString())) {
                    boolean result = true;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                } else {
                    boolean result = false;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                }
            case "xor":
                a = CONDICIONES(Raiz.getHijos().get(0), ent);
                b = CONDICIONES(Raiz.getHijos().get(1), ent);

                if ((Boolean.parseBoolean(a.Valor.toString()) == true && Boolean.parseBoolean(b.Valor.toString()) == true)
                        || (Boolean.parseBoolean(a.Valor.toString()) == false && Boolean.parseBoolean(b.Valor.toString()) == false)) {
                    boolean result = false;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                } else {
                    boolean result = true;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                }

            case "not":
                a = CONDICIONES(Raiz.getHijos().get(0), ent);

                if (Boolean.parseBoolean(a.Valor.toString()) == true) {
                    boolean result = false;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);

                } else {
                    boolean result = true;
                    return new Expresion(Simbolos.EnumTipo.booleano, result);
                }

            case "EXPRESION_RELACIONAL":
                return EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);

        }
        return new Expresion(Simbolos.EnumTipo.error, "error");
    }

    private Expresion EXPRESION_RELACIONAL(Nodo Raiz, Entorno ent) {

        switch (Raiz.getEtiqueta()) {
            case "equals":
                Expresion a = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                Expresion b = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (a.tipo == Simbolos.EnumTipo.cadena && b.tipo == Simbolos.EnumTipo.cadena) {
                    if (a.Valor.toString().equals(b.Valor.toString())) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(a.Valor.toString());
                    int n2 = Integer.parseInt(b.Valor.toString());
                    if (n1 == n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.doble && b.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());
                    if (num1 == num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());

                    if (num1 == num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.doble && b.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());

                    if (num1 == num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else {

                    if (a.Valor.toString().equals(b.Valor)) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                }

            case "diferente":
                a = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                b = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (a.tipo == Simbolos.EnumTipo.cadena && b.tipo == Simbolos.EnumTipo.cadena) {
                    if (!(a.Valor.toString().equals(b.Valor.toString()))) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(a.Valor.toString());
                    int n2 = Integer.parseInt(b.Valor.toString());
                    if (n1 != n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.doble && b.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());
                    if (num1 != num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());

                    if (num1 != num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (a.tipo == Simbolos.EnumTipo.doble && b.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(a.Valor.toString());
                    double num2 = Double.parseDouble(b.Valor.toString());

                    if (num1 != num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else {

                    if (!a.Valor.toString().equals(b.Valor)) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                }

            case "mayorigual":
                Expresion x = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                Expresion y = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(x.Valor.toString());
                    int n2 = Integer.parseInt(y.Valor.toString());
                    if (n1 >= n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());
                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 >= num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.caracter) {
                    char num1 = x.Valor.toString().charAt(0);
                    char num2 = y.Valor.toString().charAt(0);
                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.entero) {
                    char num1 = x.Valor.toString().charAt(0);
                    int num2 = Integer.parseInt(y.Valor.toString());
                    if (num1 >= num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.doble) {
                    char num1 = x.Valor.toString().charAt(0);
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.caracter) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.caracter) {
                    int num1 = Integer.parseInt(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 >= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                }
                return new Expresion(Simbolos.EnumTipo.error, "error");

            case "menorigual":

                x = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                y = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(x.Valor.toString());
                    int n2 = Integer.parseInt(y.Valor.toString());
                    if (n1 <= n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());
                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 <= num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.caracter) {
                    char num1 = x.Valor.toString().charAt(0);
                    char num2 = y.Valor.toString().charAt(0);
                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.entero) {
                    char num1 = x.Valor.toString().charAt(0);
                    int num2 = Integer.parseInt(y.Valor.toString());
                    if (num1 <= num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.doble) {
                    char num1 = x.Valor.toString().charAt(0);
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.caracter) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.caracter) {
                    int num1 = Integer.parseInt(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 <= num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                }
                return new Expresion(Simbolos.EnumTipo.error, "error");

            case "mayor":

                x = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                y = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(x.Valor.toString());
                    int n2 = Integer.parseInt(y.Valor.toString());
                    if (n1 > n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());
                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 > num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.caracter) {
                    char num1 = x.Valor.toString().charAt(0);
                    char num2 = y.Valor.toString().charAt(0);
                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.entero) {
                    char num1 = x.Valor.toString().charAt(0);
                    int num2 = Integer.parseInt(y.Valor.toString());
                    if (num1 > num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.doble) {
                    char num1 = x.Valor.toString().charAt(0);
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.caracter) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.caracter) {
                    int num1 = Integer.parseInt(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 > num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                }

                return new Expresion(Simbolos.EnumTipo.error, "error");

            case "menor":
                x = EXPRESION_RELACIONAL(Raiz.getHijos().get(0), ent);
                y = EXPRESION_RELACIONAL(Raiz.getHijos().get(1), ent);

                if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.entero) {

                    int n1 = Integer.parseInt(x.Valor.toString());
                    int n2 = Integer.parseInt(y.Valor.toString());
                    if (n1 < n2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {

                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());
                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }

                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.doble) {

                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 < num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.entero) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.caracter) {
                    char num1 = x.Valor.toString().charAt(0);
                    char num2 = y.Valor.toString().charAt(0);
                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.entero) {
                    char num1 = x.Valor.toString().charAt(0);
                    int num2 = Integer.parseInt(y.Valor.toString());
                    if (num1 < num2) {
                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.caracter && y.tipo == Simbolos.EnumTipo.doble) {
                    char num1 = x.Valor.toString().charAt(0);
                    double num2 = Double.parseDouble(y.Valor.toString());

                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.doble && y.tipo == Simbolos.EnumTipo.caracter) {
                    double num1 = Double.parseDouble(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                } else if (x.tipo == Simbolos.EnumTipo.entero && y.tipo == Simbolos.EnumTipo.caracter) {
                    int num1 = Integer.parseInt(x.Valor.toString());
                    char num2 = y.Valor.toString().charAt(0);

                    if (num1 < num2) {

                        boolean result = true;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    } else {
                        boolean result = false;
                        return new Expresion(Simbolos.EnumTipo.booleano, result);
                    }
                }
                return new Expresion(Simbolos.EnumTipo.error, "error");
            case "VECTORVALOR":
                return VECTORVALOR(Raiz, ent);
            case "VALOR":
                return VALOR(Raiz.getHijos().get(0), ent);
        }

        return new Expresion(Simbolos.EnumTipo.error, "error");
    }

    private void SINO(Nodo Raiz, Entorno ent) {
        this.L_INSTRUCCIONES(Raiz.getHijos().get(0), ent);
    }

    private boolean SINOSI(Nodo Raiz, Entorno ent) {
        boolean ver = false;
        switch (Raiz.getHijos().size()) {
            case 2:
                Expresion condicion = this.CONDICION(Raiz.getHijos().get(0), ent);
                boolean cod = Boolean.parseBoolean(condicion.Valor.toString());
                Nodo inst = Raiz.getHijos().get(1);
                if (cod) {
                    this.L_INSTRUCCIONES(inst, ent);
                    ver = cod;
                }
                break;

            case 3:
                condicion = this.CONDICION(Raiz.getHijos().get(1), ent);
                cod = Boolean.parseBoolean(condicion.Valor.toString());
                inst = Raiz.getHijos().get(2);
                if (cod) {
                    // Entorno local = new Entorno(ent);
                    this.L_INSTRUCCIONES(inst, ent);
                    ver = cod;
                } else {
                    //   Entorno local = new Entorno(ent);
                    ver = this.SINOSI(Raiz.getHijos().get(0), ent);
                }
                break;
        }
        return ver;
    }

    private void MIENTRAS(Nodo Raiz, Entorno ent) {

        Expresion resultado = this.CONDICION(Raiz.getHijos().get(0), ent);
        if (resultado.tipo == Simbolos.EnumTipo.error) {
            System.out.println("Error en la funcion mientras");

            ErrorSemantico er = new ErrorSemantico("error Semantico", resultado.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la condicion no es valido ");
            errorsemantico.add(er);

            return;
        }
        Nodo inst = Raiz.getHijos().get(1);
        if (inst.getHijos().size() > 0) {
            while (Boolean.parseBoolean(this.CONDICION(Raiz.getHijos().get(0), ent).Valor.toString())) {
                Entorno local = new Entorno(ent);
                this.L_INSTRUCCIONES(inst, local);
            }
        }
    }

    private void REPETIR(Nodo Raiz, Entorno ent) {
        Expresion resultado = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
        if (resultado.tipo == Simbolos.EnumTipo.error) {
            System.out.println("Error en la funcion repetir");
            ErrorSemantico er = new ErrorSemantico("error Semantico", resultado.Valor.toString(), Raiz.getFila(), Raiz.getColumna(), "error en la valor incorrecto");
            errorsemantico.add(er);

            return;
        }
        Nodo nodobloque = Raiz.getHijos().get(1);
        if (nodobloque.getHijos().size() > 0) {
            int iterador = Integer.parseInt(resultado.Valor.toString());
            while (iterador > 0) {
                Entorno local = new Entorno(ent);
                this.L_INSTRUCCIONES(nodobloque, local);
                iterador--;
            }
        }
    }

    private Expresion OPERACION_ARITMETICA(Nodo Raiz, Entorno ent) {

        switch (Raiz.getEtiqueta()) {
            case "id":
                Simbolos sim = ent.buscar(Raiz.getValor());
                if (sim != null) {

                    return new Expresion(sim.tipo, sim.valor);
                } else {
                    System.out.println("errror no existe el id");
                    ErrorSemantico er = new ErrorSemantico("error Semantico", sim.valor.toString(), sim.Fila, sim.Columna, "errror no existe el id");
                    errorsemantico.add(er);
                    return new Expresion(Simbolos.EnumTipo.error, "error");
                }

            case "entero":
                return new Expresion(Simbolos.EnumTipo.entero, Raiz.getValor());
            case "mas":
                Expresion a = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
                Expresion b = OPERACION_ARITMETICA(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) + Integer.parseInt(b.Valor.toString()));
                }
            case "menos":
                a = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
                b = OPERACION_ARITMETICA(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) - Integer.parseInt(b.Valor.toString()));
                }
            case "por":
                a = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
                b = OPERACION_ARITMETICA(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) * Integer.parseInt(b.Valor.toString()));
                }
            case "div":
                a = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
                b = OPERACION_ARITMETICA(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    if (Integer.parseInt(b.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + a.tipo + " / " + b.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) / Integer.parseInt(b.Valor.toString()));
                }
            case "umenos":
                a = OPERACION_ARITMETICA(Raiz.getHijos().get(0), ent);
                if (a.tipo == Simbolos.EnumTipo.entero) {
                    int c = -Integer.parseInt(a.Valor.toString());
                    return new Expresion(Simbolos.EnumTipo.entero, c);
                }

            case "VECTORVALOR":
                return VECTORVALOR(Raiz, ent);
        }
        return new Expresion(Simbolos.EnumTipo.error, "error");
    }

}
