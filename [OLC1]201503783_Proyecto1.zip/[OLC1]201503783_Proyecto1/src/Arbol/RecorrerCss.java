/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arbol;

import Componentes.ComponenteCss;
import Componentes.RGB;
import Componentes.Selector;
import Ent.Entorno;
import java.util.ArrayList;

/**
 *
 * @author edi
 */
public class RecorrerCss {
   
    public static ArrayList<ArrayList<Selector>> ListaCSS = new ArrayList();     
    public void S(Nodo Raiz, Entorno ent){
      
            for(Nodo hijo: Raiz.getHijos()){
               switch(hijo.getEtiqueta()){
                   case "LISTASELECTOR":
                     ListaCSS.add(this.LISTASELECTOR(hijo, ent));
                   break;
               }
            }
    }
    
    private ArrayList<Selector> LISTASELECTOR(Nodo Raiz, Entorno ent){
           ArrayList<Selector>   listaselector = new ArrayList();
        for(Nodo hijo: Raiz.getHijos()){
               switch(hijo.getEtiqueta()){
                   case "SELECTOR":
                    listaselector.add(this.SELECTOR(hijo, ent));
                   break;
               }
            }
         return   listaselector;
    }
    private Selector SELECTOR(Nodo Raiz, Entorno ent){
       ArrayList<ComponenteCss> listaAdyacente = null;    
          String id ="";
        for(Nodo hijo: Raiz.getHijos()){
               switch(hijo.getEtiqueta()){
               
                   case "id":
                       id = hijo.getValor();
                   break;
                   case "ADYACENTE":
                   listaAdyacente = this.ADYACENTE(hijo, ent);
                   break;
               }
            }
        return new Selector(id,listaAdyacente);    
    }
    
    private ArrayList<ComponenteCss> ADYACENTE(Nodo Raiz, Entorno ent){
            ArrayList<ComponenteCss> listaAdyacente = new ArrayList();    
           for(Nodo hijo: Raiz.getHijos()){
               switch(hijo.getEtiqueta()){
               case "CUERPOADYACENTE":
                  listaAdyacente.add(this.CUERPOADYACENTE(hijo));
                   break;
               }
            } 
      return listaAdyacente;
    }
    
    private ComponenteCss CUERPOADYACENTE(Nodo Raiz){
        
        if (Raiz.getHijos().get(1).getEtiqueta().equals("RGB")) {
            return new ComponenteCss(Raiz.getHijos().get(0).getValor(),rgb(Raiz.getHijos().get(1)),Raiz.getHijos().get(1).getEtiqueta());
        } else {
            return new ComponenteCss(Raiz.getHijos().get(0).getValor(), Raiz.getHijos().get(1).getValor(),Raiz.getHijos().get(1).getEtiqueta());
        
        } 
    }
    
    private RGB rgb(Nodo Raiz)
    {
         return new RGB(Integer.parseInt( Raiz.getHijos().get(0).getValor()),  
                 Integer.parseInt( Raiz.getHijos().get(1).getValor()),
                 Integer.parseInt( Raiz.getHijos().get(2).getValor())
                 );    
     }
    
}
