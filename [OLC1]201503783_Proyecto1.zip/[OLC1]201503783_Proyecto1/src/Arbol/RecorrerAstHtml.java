/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arbol;

import Ent.Entorno;
import Ent.Simbolos;
import java.util.ArrayList;

/**
 *
 * @author edi
 */
public class RecorrerAstHtml {
  public static ArrayList<String> titulo = new ArrayList();  
  public static ArrayList<String> noufe = new ArrayList();
  public static ArrayList<String> identificador = new ArrayList();
  public static ArrayList<String> html = new ArrayList();
  public void ejecutar(Nodo Raiz){
              
    //  this.S(Raiz, ent);
  }  
     public void S(Nodo Raiz ,Entorno ent){

         // this.HTML(Raiz.getHijos().get(0),ent);
            html.add(this.HTML(Raiz.getHijos().get(0),ent));
     }
  
  public String HTML(Nodo Raiz, Entorno ent){
    String a ="<html>";     
      a+=this.CUERPOHTML(Raiz.getHijos().get(0),ent)+"\n";
        a +="</html>";
      return a;
  } 

  public String CUERPOHTML(Nodo Raiz,Entorno ent){
     String a ="";
     for(Nodo hijo : Raiz.getHijos())
       {
            switch(hijo.getEtiqueta()){
                case "HEAD":
              a +=  this.HEAD(hijo,ent)+"\n";
                    break;
                case "BODY":
                  a +=   this.BODY(hijo,ent)+"\n";
                    break;
            }   
       }
     return a;
  }

    public String HEAD(Nodo Raiz,Entorno ent){
       String a ="<head>"+"\n";
       a+= this.TITLE(Raiz.getHijos().get(0),ent);
       a+="</head>";
       return a;
    }
  
   public String BODY(Nodo Raiz,Entorno ent){
       
     return this.CUERPO(Raiz.getHijos().get(0),ent);
   }
   
    public String CUERPO(Nodo Raiz,Entorno ent){
     String a ="<body>"+"\n";
    
        for(Nodo hijo : Raiz.getHijos())
       {
            switch(hijo.getEtiqueta()){
                case "NOUFE":
              a += this.NOUFE(hijo)+"\n";
                    break;
                case "DIV":
                 a +=    this.DIV(hijo,ent)+"\n";
                    break;
            }   
       }
      a+="</body>";
     return a;   
   }
    
    public String DIV(Nodo Raiz,Entorno entor){
      identificador.add(Raiz.getHijos().get(1).getValor());
     
     String a ="<div"+ Raiz.getHijos().get(0).getEtiqueta()+"="+  Raiz.getHijos().get(1).getValor()+">"+"</div"; 
                        
             Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.cadena, Raiz.getHijos().get(1).getValor(), Raiz.getColumna(), Raiz.getFila());
             entor.put(Raiz.getHijos().get(0).getEtiqueta(), nuevosimbolo);
                 
     
     
        return a;
    
    }
    
    public String NOUFE(Nodo Raiz){
        noufe.add( Raiz.getHijos().get(0).getValor());
         String a ="<noufe>"+ Raiz.getHijos().get(0).getValor()+"</noufe>"; 
        return a; 
    }
    
    public String TITLE(Nodo Raiz,Entorno entor){
        titulo.add( Raiz.getHijos().get(0).getValor());
        String a ="<title>"+ Raiz.getHijos().get(0).getValor()+"</title>"; 
       
             Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.cadena, Raiz.getHijos().get(0).getValor(), Raiz.getColumna(), Raiz.getFila());
             entor.put("title", nuevosimbolo);
        return a;      
    
    }
    
    
    
    
    
    
}
