/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Arbol;

import Aplicacion.Ventana;
import static Aplicacion.Ventana.archivo;
import static Arbol.RecorrerAstHtml.html;
import static Arbol.RecorrerAstHtml.identificador;
import static Arbol.RecorrerAstHtml.titulo;
import Ent.Entorno;
import Ent.Simbolos;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//import static olc1.pkg201503783_proyecto1.OLC1201503783_Proyecto1.vntinicial;

/**
 *
 * @author edi
 */
public class RecorrerAstUfe {

    public void Recorrer(Nodo Raiz,Entorno ent) {
            this.INICIO(Raiz, ent);
   
    }
    
    public void INICIO(Nodo Raiz, Entorno ent) {
        Raiz.getHijos().forEach((Nodo hijo) -> {
            switch (hijo.getEtiqueta()) {
                case "DECLARACION"://listo
                       this.DECLARACION(hijo, ent);
                    break;
                case "IMPORTAR":
                          this.IMPORTAR(hijo, ent);
                    break;
                case "ASIGNACION"://listo
                       this.ASIGNACION(hijo, ent);
                    break;
                case "ARREGLOS":  //listo
                       this.ARREGLOS(hijo, ent);
                    break;
                case "RENDER":
                      // IGNORAR
                    break;
                case "DECLARACIONVECTOR": //listo
                        this.DECLARACIONVECTOR(hijo, ent);
                    break;
                case "ASIGNVECTOR": //listo
                        this.ASIGNVECTOR(hijo, ent);
                    break;
                case "COMPONENTE":
                    this.COMPONENTE(hijo, ent);
                    break;

                default:
                    break;
            }
        });

    }
    
    private String LeerArchivo(String ruta) {
        String temp = "";
        try {
            BufferedReader bf = new BufferedReader(new FileReader(ruta));
            String bfRead;
            while ((bfRead = bf.readLine()) != null) {
                temp = temp + bfRead + "\n";
            }
        } catch (Exception e) {
        }
        return temp;
    }
    
    
    public void IMPORTAR(Nodo Raiz, Entorno ent){
          switch(Raiz.getHijos().size()){
              case 1:
                       Analizador3 ana = new Analizador3();
                       
                          File a = new File(  archivo.getAbsolutePath() +File.separator  +Raiz.getHijos().get(0).getValor().replace(".", ""));
                             // "/home/edi/eytr/Entradas/Entrada1/src/"
                          if(a.exists()){
                                              
                              ana.Analizar ( LeerArchivo ( archivo.getAbsolutePath() +File.separator  +Raiz.getHijos().get(0).getValor().replace(".", "")), ent);
                          } else{
                                  JOptionPane.showMessageDialog(null, "no existe el achivo");
                          
                          
                          }       
                       
                       
                       
                       
                       break;
              case 2:
                                          
                       Analizador2  ana2 = new Analizador2();
                       a = new File( archivo.getAbsolutePath() +File.separator  +Raiz.getHijos().get(0).getValor().replace(".", ""));
                         if(a.exists()){
                           ana2.Analizar(LeerArchivo ( archivo.getAbsolutePath() +File.separator  +Raiz.getHijos().get(0).getValor().replace(".", "")), ent);
                     }else{
                                  JOptionPane.showMessageDialog(null, "no existe el achivo");
                          }           
                      
                       
                       break;
          }
    }
    
    
    //*******************DECLARACION **********************************************
    
    
    
    public void DECLARACION(Nodo Raiz, Entorno ent) {
        this.LISTASIGNACIONES(Raiz.getHijos().get(1), ent);
    }

    public void LISTASIGNACIONES(Nodo Raiz, Entorno ent) {
        this.ASIGNAR(Raiz.getHijos().get(0), ent);
    }

    public void ASIGNAR(Nodo Raiz, Entorno ent) {

        switch (Raiz.getHijos().size()) {
            case 1:
                String id1 = Raiz.getHijos().get(0).getValor();
                Simbolos nu = new Simbolos(Simbolos.EnumTipo.var, null, Raiz.getColumna(), Raiz.getFila());
                ent.put(id1, nu);

                break;

            case 2:

                Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
                String id = Raiz.getHijos().get(0).getValor();

                if (Simbolos.EnumTipo.error == resultado.tipo) {
                    System.out.println("Error no se permite");
                    return;
                }

                if (null != resultado.tipo) {
                    switch (resultado.tipo) {
                        case entero: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case cadena: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case caracter: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case booleano: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        case doble: {
                            Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                            ent.put(id, nuevo);
                            break;
                        }
                        default:
                            break;
                    }
                }
        }

    }
 
//*******************ASIGNACION **********************************************
    
    public void ASIGNACION(Nodo Raiz, Entorno ent) {

        Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
        if (Simbolos.EnumTipo.error == resultado.tipo) {
            System.out.println("Error no se permite");
            return;
        }

        String id = Raiz.getHijos().get(0).getValor();
        Simbolos sim = ent.buscar(id);
        if (sim != null) {
            if (null != resultado.tipo) {
                switch (resultado.tipo) {
                    case entero: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case cadena: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case caracter: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case booleano: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case doble: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    default:
                        System.out.println("error en el simbolo");
                        break;
                }
            }
        } else {
            System.out.println("no existe simbolo");
        }

    }


//*****************************Declaracion y Asignacion y Vecotes********************************************
    private void ASIGNVECTOR(Nodo Raiz, Entorno ent) {
        Expresion resultado = VALOR(Raiz.getHijos().get(1), ent);
        String id = VECTORVALORASIGNACION(Raiz.getHijos().get(0), ent);
        if (Simbolos.EnumTipo.error == resultado.tipo) {
            System.out.println("Error no se permite");
            return;
        }
        Simbolos sim = ent.buscar(id);
        if (sim != null) {
            if (null != resultado.tipo) {
                switch (resultado.tipo) {
                    case entero: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.entero, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case cadena: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.cadena, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case caracter: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.caracter, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case booleano: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.booleano, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    case doble: {
                        Simbolos nuevo = new Simbolos(Simbolos.EnumTipo.doble, resultado.Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id, nuevo);
                        break;
                    }
                    default:
                        System.out.println("error en el simbolo");
                        break;
                }
            }
        }

    }

    private void DECLARACIONVECTOR(Nodo Raiz, Entorno ent) {
        this.DEVECTORVALOR(Raiz.getHijos().get(1), ent);
    }

    private void DEVECTORVALOR(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        int tam = Integer.parseInt(resultado.Valor.toString());
        int i;
        for (i = 0; i <= tam; i++) {
            Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.var, null, Raiz.getColumna(), Raiz.getFila());
            ent.put(id + "[" + i + "]", nuevosimbolo);
        }
    }

    private Expresion EXPARREGLO(Nodo Raiz, Entorno ent) {

        switch (Raiz.getEtiqueta()) {
            case "id":
                Simbolos sim = ent.buscar(Raiz.getValor());
                return new Expresion(sim.tipo, sim.valor);
            case "entero":
                return new Expresion(Simbolos.EnumTipo.entero, Raiz.getValor());
            case "mas":
                Expresion a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                Expresion b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) + Integer.parseInt(b.Valor.toString()));
                }
            case "menos":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) - Integer.parseInt(b.Valor.toString()));
                }
            case "por":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) * Integer.parseInt(b.Valor.toString()));
                }
            case "div":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                b = EXPARREGLO(Raiz.getHijos().get(1), ent);
                if (a.tipo == Simbolos.EnumTipo.entero && b.tipo == Simbolos.EnumTipo.entero) {
                    if (Integer.parseInt(b.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + a.tipo + " / " + b.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(a.Valor.toString()) / Integer.parseInt(b.Valor.toString()));
                }
            case "umenos":
                a = EXPARREGLO(Raiz.getHijos().get(0), ent);
                if (a.tipo == Simbolos.EnumTipo.entero) {
                    int c = -Integer.parseInt(a.Valor.toString());
                    return new Expresion(Simbolos.EnumTipo.entero, c);
                }

        }
        return new Expresion(Simbolos.EnumTipo.error, "error");
    }
    
    public void ARREGLOS(Nodo Raiz, Entorno ent) {
        this.ASIGNARARREGLO1(Raiz.getHijos().get(1), ent);

    }

    public ArrayList<Expresion> LISTEXP(Nodo Raiz, Entorno ent) {
        ArrayList<Expresion> lista = new ArrayList();
        Raiz.getHijos().forEach((Nodo hijo) -> {
            lista.add(this.VALOR(hijo, ent));
        });
        return lista;
    }

    private void ASIGNARARREGLO1(Nodo Raiz, Entorno ent) {

        ArrayList<Expresion> lista = LISTEXP(Raiz.getHijos().get(1), ent);
        String id = Raiz.getHijos().get(0).getValor();
        int i;
        for (i = 0; i < lista.size(); i++) {
            if (Simbolos.EnumTipo.error == lista.get(i).tipo) {
                System.out.println("Error no se permite");
                return;
            }

            if (null != lista.get(i).tipo) {
                switch (lista.get(i).tipo) {
                    case entero: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.entero, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case cadena: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.cadena, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case caracter: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.caracter, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case booleano: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.booleano, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                    case doble: {
                        Simbolos nuevosimbolo = new Simbolos(Simbolos.EnumTipo.doble, lista.get(i).Valor, Raiz.getColumna(), Raiz.getFila());
                        ent.put(id + "[" + i + "]", nuevosimbolo);
                        break;
                    }
                }
            }
        }

    }

    private String VECTORVALORASIGNACION(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        return id + "[" + resultado.Valor.toString() + "]";
    }
    
    public Expresion VALOR(Nodo Raiz, Entorno ent) {
        //     System.out.println("Error no se permite");

        switch (Raiz.getEtiqueta()) {
            case "cadena":
                return new Expresion(Simbolos.EnumTipo.cadena, Raiz.getValor());

            case "entero":
                return new Expresion(Simbolos.EnumTipo.entero, Raiz.getValor());

            case "decimal":
                return new Expresion(Simbolos.EnumTipo.doble, Raiz.getValor());

            case "caracter":
                return new Expresion(Simbolos.EnumTipo.caracter, Raiz.getValor());

            case "verdadero":
                return new Expresion(Simbolos.EnumTipo.booleano, Raiz.getValor());

            case "falso":
                return new Expresion(Simbolos.EnumTipo.booleano, Raiz.getValor());

            case "id":
                Simbolos sim = ent.buscar(Raiz.getValor());
                if (sim != null) {
                    if (sim.valor != null) {
                        return new Expresion(sim.tipo, sim.valor);
                    } else {
                        System.out.println("el no esta asignado");
                        return new Expresion(Simbolos.EnumTipo.error, "error");
                    }

                } else {
                    System.out.println("no existe simbolos**********");
                    return new Expresion(Simbolos.EnumTipo.error, "error");

                }

            case "mas":
                Expresion hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                Expresion hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {

                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) + Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) + Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) + Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.booleano && hijoDerecho.tipo == Simbolos.EnumTipo.cadena) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.cadena && hijoDerecho.tipo == Simbolos.EnumTipo.booleano) {
                    return new Expresion(Simbolos.EnumTipo.cadena, hijoIzquierdo.Valor.toString() + hijoDerecho.Valor.toString());
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a + b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a + b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a + b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a + b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                }
                System.out.println("operacion incorrecta: " + hijoIzquierdo.tipo + " mas " + hijoDerecho.tipo);
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "menos":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);
                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) - Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) - Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a - b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a - b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a - b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a - b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) - Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }

                System.out.println("operacion incorrecta: " + hijoIzquierdo.tipo + " menos " + hijoDerecho.tipo);
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "por":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);
                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) * Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) * Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    int total = a * b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    int total = a * b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = a * b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = a * b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    int total = Character.getNumericValue(a) * Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }

                System.out.println("operacion incorrecta: " + hijoIzquierdo.tipo + " * " + hijoDerecho.tipo);
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "div":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    if (Double.parseDouble(hijoDerecho.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    if (Integer.parseInt(hijoDerecho.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.entero, Integer.parseInt(hijoIzquierdo.Valor.toString()) / Integer.parseInt(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    if (Integer.parseInt(hijoDerecho.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    if (Double.parseDouble(hijoDerecho.Valor.toString()) == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);
                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    return new Expresion(Simbolos.EnumTipo.doble, Double.parseDouble(hijoIzquierdo.Valor.toString()) / Double.parseDouble(hijoDerecho.Valor.toString()));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    if (b == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }

                    int total = a / b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    int total = a / b;
                    return new Expresion(Simbolos.EnumTipo.entero, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    if (b == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    double total = a / b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    double total = a / b;
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    if (b == 0) {
                        System.out.println("operacion incorrecta division entre cero: " + hijoIzquierdo.tipo + " / " + hijoDerecho.Valor);

                        return new Expresion(Simbolos.EnumTipo.error, "@error");
                    }
                    int total = Character.getNumericValue(a) / Character.getNumericValue(b);
                    return new Expresion(Simbolos.EnumTipo.entero, total);

                }
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "potencia":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);
                hijoDerecho = VALOR(Raiz.getHijos().get(1), ent);

                if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {

                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {

                    double a = Double.parseDouble(hijoIzquierdo.Valor.toString());
                    double b = Double.parseDouble(hijoDerecho.Valor.toString());
                    double c = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, c);

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    return new Expresion(Simbolos.EnumTipo.doble, Math.pow(Double.parseDouble(hijoIzquierdo.Valor.toString()), Double.parseDouble(hijoDerecho.Valor.toString())));

                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.entero) {
                    int a = hijoIzquierdo.Valor.toString().charAt(0);
                    int b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.entero && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    int a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    int b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.doble) {
                    double a = hijoIzquierdo.Valor.toString().charAt(0);
                    double b = Integer.parseInt(hijoDerecho.Valor.toString());
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.doble && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {
                    double a = Integer.parseInt(hijoIzquierdo.Valor.toString());
                    double b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);
                } else if (hijoIzquierdo.tipo == Simbolos.EnumTipo.caracter && hijoDerecho.tipo == Simbolos.EnumTipo.caracter) {

                    char a = hijoIzquierdo.Valor.toString().charAt(0);
                    char b = hijoDerecho.Valor.toString().charAt(0);
                    double total = Math.pow(a, b);
                    return new Expresion(Simbolos.EnumTipo.doble, total);

                }
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "umenos":
                hijoIzquierdo = VALOR(Raiz.getHijos().get(0), ent);

                if (null != hijoIzquierdo.tipo) {
                    switch (hijoIzquierdo.tipo) {
                        case doble: {
                            double a = -Double.parseDouble(hijoIzquierdo.Valor.toString());
                            return new Expresion(Simbolos.EnumTipo.entero, a);
                        }
                        case entero: {
                            int a = -Integer.parseInt(hijoIzquierdo.Valor.toString());
                            return new Expresion(Simbolos.EnumTipo.entero, a);
                        }
                        case caracter: {
                            char a = hijoIzquierdo.Valor.toString().charAt(0);
                            double total = -a;
                            return new Expresion(Simbolos.EnumTipo.entero, total);
                        }
                        default:
                            break;
                    }
                }
                return new Expresion(Simbolos.EnumTipo.error, "@error");

            case "VECTORVALOR":
                return VECTORVALOR(Raiz, ent);

        }
        return new Expresion(Simbolos.EnumTipo.error, "@error");
    }
    
    private Expresion VECTORVALOR(Nodo Raiz, Entorno ent) {
        String id = Raiz.getHijos().get(0).getValor();
        Expresion resultado = EXPARREGLO(Raiz.getHijos().get(1), ent);
        int i = Integer.parseInt(resultado.Valor.toString());
        Simbolos sim = ent.buscar(id + "[" + i + "]");
        if (sim != null) {
            return new Expresion(sim.tipo, sim.valor);
        } else {
            System.out.println("no existe el id");
        }
        return new Expresion(Simbolos.EnumTipo.error, "@error");
    }    
    
  private void COMPONENTE(Nodo Raiz, Entorno ent)
    {
                String id1 = Raiz.getHijos().get(0).getValor();
                System.out.println("******  id de los paneles "+id1    );
                Simbolos nu = new Simbolos(Simbolos.EnumTipo.component, Raiz.getHijos().get(1), Raiz.getColumna(), Raiz.getFila());
                ent.put(id1, nu);
         //    this.CONTENIDO(Raiz.getHijos().get(1), ent);
   
    }
    
  
  private void CONTENIDO(Nodo Raiz, Entorno ent) {

        for (Nodo hijo : Raiz.getHijos()) {
            switch (hijo.getEtiqueta()) {
                case "SENTENCIAS":
                  //  this.SENTENCIAS(hijo, ent);
                    break;
                case "DECLARACION":
                    this.DECLARACION(hijo, ent);
                    break;
                case "ASIGNACION":
                    this.ASIGNACION(hijo, ent);
                    break;
                case "RETORNAR":
                 //   this.RETONAR(hijo, ent);
                    break;
                case "IMPRIMIR":
                 //   this.IMPRIMIR(hijo, ent);
                    break;
                case "ARREGLOS":  //listo
                    this.ARREGLOS(hijo, ent);
                    break;
                case "DECLARACIONVECTOR": //listo
                    this.DECLARACIONVECTOR(hijo, ent);
                    break;
                case "ASIGNVECTOR": //listo
                    this.ASIGNVECTOR(hijo, ent);
                    break;

            }
        }

    }
  
  
  
    
    
}
