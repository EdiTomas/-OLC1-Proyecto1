/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FaseCompilador2;


/**
 *
 * @author edi
 */
public class GeneradorCompilador2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        generarcompiladores1();
    }
    
    public static void generarcompiladores1() {
        try {
            String ruta = "src/FaseCompilador2/";
            String opcFlex[] = {ruta + "scanner.jflex", "-d", ruta};
            jflex.Main.generate(opcFlex);

            String opcCUP[] = {"-destdir", ruta, "-parser", "Parser" ,"-symbols","simbolos", ruta + "Parser.cup"};
            java_cup.Main.main(opcCUP);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    
}
