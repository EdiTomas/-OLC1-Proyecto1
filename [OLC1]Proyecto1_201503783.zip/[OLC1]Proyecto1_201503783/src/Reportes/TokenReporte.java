/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Tomas
 */
public class TokenReporte {
    
  public  String palabra;
  public  int Fila;
  public  int Columna;
  public  String Descripcion;  
    public TokenReporte(String palabra, int Fila,int Columna, String Descripcion){
               this.palabra = palabra;
               this.Fila = Fila;
               this.Columna =Columna;
               this.Descripcion = Descripcion; 
    }
    
    
}
