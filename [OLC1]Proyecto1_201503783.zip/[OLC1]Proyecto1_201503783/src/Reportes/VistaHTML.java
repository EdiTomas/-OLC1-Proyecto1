/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

import static FaseCompilador.Lexico.listaError;
import static FaseCompilador.Lexico.tokens;
import static FaseCompilador.Sintactico.ContenidoHTML;
import static FaseCompilador.Sintactico.ErrorSintactico;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Tomas
 */
public class VistaHTML {

    public static String FechaActual() {
        Date fecha = new Date();

        SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY " + " HH:mm:ss " + "a");
        return formatofecha.format(fecha);
    }

    public String PruebaTokens() {

        String cadenaconTextoHTML = "";

        cadenaconTextoHTML += "<html>"
                + " <head>" + "\n"
                + "<title> Reportes1 </title>" + "\n" // "< font color=white>"   D</FONT>
                + "<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> " + "\n"
                //    + " <style type= text/css> "+" tr:hover td{   background:#369681;     color: white  }" +"</style> "

                + " <h1><center> <font color= white > REPORTE DE TOKENS  </font></center></h1>" + "\n"
                + " </head>"
                + " <body  bgcolor= #632432 >" //#800000
                + "<center>" + "<table   BORDER = 0  bgcolor=white cellspacing=0 cellpadding=10  > "
                + "<tr bgcolor= #246355   >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" + "\n"
                + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>" + "\n"
                + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>" + "\n"
                + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>" + "\n"
                + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>" + "\n"
                + "</tr>" + "</B>";

        for (int i = 0; i < tokens.size(); i++) {

            if (i % 2 == 0) {

                cadenaconTextoHTML += "<tr bgcolor=#ddd      >"
                        + "<td   >" + (i + 1) + "\n" //#87CEFA
                        + "</td>" + "<td >" + tokens.get(i).palabra + "\n"
                        + "</td>" + "<td >" + (tokens.get(i).Fila + 1) + "\n"
                        + "</td>" + "<td >" + (tokens.get(i).Columna + 1) + "\n"
                        + "</td>" + "<td    >" + (tokens.get(i).Descripcion) + "\n"
                        + "</td>" + "</tr>" + "\n";

            } else {

                cadenaconTextoHTML
                        += "<tr bgcolor=#F5F5F5 >" + "<td>" + (i + 1) + "\n"
                        + "</td>" + "<td  >" + tokens.get(i).palabra + "\n"
                        + "</td>" + "<td   >" + (tokens.get(i).Fila + 1) + "\n"
                        + "</td>" + "<td   >" + (tokens.get(i).Columna + 1) + "\n"
                        + "</td>" + "<td    >" + (tokens.get(i).Descripcion) + "\n"
                        + "</td>" + "</tr>" + "\n";

            }

        }
        cadenaconTextoHTML += "</table>" + "</center>" + "\n" + "</body>" + "\n" + "</html>";

//nos aseguramos de cerrar el archivo
        return cadenaconTextoHTML;

    }

    public String GenerarReportesErroresLexicos() {

        String ReporteError = "";

        //escribimos un archivo de texto con la estructura de html
        ReporteError += "<html>"
                + " <head>"
                + "<title> Reportes2 </title>"
                + // "< font color=white>"   D</FONT>
                "<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> "
                + " <h1><center> <font color= white >  ERRORES LEXICOS </font></center></h1>"
                + " </head>"
                + " <body  bgcolor= black >"
                + //#800000
                "<center>" + "<table   BORDER = 0    bgcolor=white cellspacing=0 cellpadding=10  > "
                + //#008080
                "<tr bgcolor= #246355   >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" //#008080
                + "<td>" + "<B>" + "<font color= white >" + "Tipo" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>"
                + "</tr>" + "</B>";

        for (int i = 0; i < listaError.size(); i++) {

            if (i % 2 == 0) {

                ReporteError += "<tr bgcolor=#ddd >"
                        + "<td   >" + (i + 1) //#87CEFA
                        + "</td>" + "<td>" + listaError.get(i).tipo
                        + "</td>" + "<td>" + listaError.get(i).error
                        + "</td>" + "<td>" + listaError.get(i).linea
                        + "</td>" + "<td>" + listaError.get(i).columna
                        + "</td>" + "<td>" + listaError.get(i).Descripcion + "</td>" + "</tr>";

            } else {

                ReporteError += "<tr bgcolor=#F5F5F5    >" + "<td>" + (i + 1)
                        + "</td>" + "<td>" + listaError.get(i).tipo
                        + "</td>" + "<td>" + listaError.get(i).error
                        + "</td>" + "<td>" + listaError.get(i).linea
                        + "</td>" + "<td>" + listaError.get(i).columna
                        + "</td>" + "<td>" + listaError.get(i).Descripcion + "</td>" + "</tr>";
            }

        }
        ReporteError += "</table>" + "</center>"
                + "</body>"
                + "</html>";

        return ReporteError;

    }

    public String GenerarReportesErroresSintacticos() {
        String ReporteSintactico = "";
        ReporteSintactico += "<html>"
                + "<head>"
                + "<title> Reportes3 </title>"
                + // "< font color=white>"   D</FONT>
                "<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> "
                + " <h1><center> <font color= white > ERRORES SINTACTICOS  </font></center></h1>"
                + " </head>"
                + " <body  bgcolor= #632432 >"
                + //#800000
                "<center>" + "<table   BORDER = 0    bgcolor=white cellspacing=0 cellpadding=10  > "
                + //#008080
                "<tr bgcolor= black >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" //#008080
                + "<td>" + "<B>" + "<font color= white >" + "Tipo" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>"
                + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>"
                + "</tr>" + "</B>";

        for (int i = 0; i < ErrorSintactico.size(); i++) {

            if (i % 2 == 0) {
                ReporteSintactico
                        += "<tr bgcolor=#ddd      >"
                        + "<td>" + (i + 1) //#87CEFA
                        + "</td>" + "<td>" + ErrorSintactico.get(i).tipo
                        + "</td>" + "<td>" + ErrorSintactico.get(i).error
                        + "</td>" + "<td>" + ErrorSintactico.get(i).linea
                        + "</td>" + "<td>" + ErrorSintactico.get(i).columna
                        + "</td>" + "<td>" + ErrorSintactico.get(i).Descripcion + "</td>" + "</tr>";
            } else {

                ReporteSintactico
                        += "<tr bgcolor=#F5F5F5    >" + "<td>" + (i + 1)
                        + "</td>" + "<td>" + ErrorSintactico.get(i).tipo
                        + "</td>" + "<td>" + ErrorSintactico.get(i).error
                        + "</td>" + "<td>" + ErrorSintactico.get(i).linea
                        + "</td>" + "<td>" + ErrorSintactico.get(i).columna
                        + "</td>" + "<td>" + ErrorSintactico.get(i).Descripcion + "</td>" + "</tr>";
            }
        }
        ReporteSintactico += "</table>" + "</center>"
                + "</body>"
                + "</html>";
        return ReporteSintactico;
    }

public String ResultaPagina(){
   String cadena = "";
        cadena = ContenidoHTML.get(0);
  return cadena;
}




}
