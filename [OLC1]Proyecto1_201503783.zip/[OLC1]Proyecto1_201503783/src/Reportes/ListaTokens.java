/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

import static FaseCompilador.Lexico.tokens;
import static FaseCompilador.Lexico.listaError;
import static FaseCompilador.Sintactico.ContenidoHTML;
import static FaseCompilador.Sintactico.ErrorSintactico;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Tomas
 */
public class ListaTokens {

    public ListaTokens() {

    }

    public static String FechaActual() {
        Date fecha = new Date();

        SimpleDateFormat formatofecha = new SimpleDateFormat("dd/MM/YYYY " + " HH:mm:ss " + "a");
        return formatofecha.format(fecha);
    }

    //*******************************Generar Reportes *****************************************************************  
    public void GenerarReportesTokens() {
        try {
            FileWriter archivo = new FileWriter("C:\\Users\\Tomas\\OneDrive\\Documentos\\NetBeansProjects\\[OLC1]Proyecto1_201503783\\src\\Manual\\tokensReporte.html");
            PrintWriter escritura = new PrintWriter(archivo);
            //escribimos un archivo de texto con la estructura de html
            escritura.println("<html>");
            escritura.println(" <head>");
            escritura.println("<title> Reportes1 </title>");   // "< font color=white>"   D</FONT>
            escritura.println("<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> ");
            escritura.println(" <style type=\"text/css\">\n"
                    + //  " td{background:#ccc;}\n" +
                    " tr:hover td{   background:#369681;     color: white  }\n"
                    + "</style> "
            );

            escritura.println(" <h1><center> <font color= white > REPORTE DE TOKENS  </font></center></h1>");
            escritura.println(" </head>");
            escritura.println(" <body  bgcolor= #632432 >");    //#800000
            escritura.println("<center>" + "<table   BORDER = 0  width =100%  bgcolor=white cellspacing=0 cellpadding=10  > ");  //#008080
            escritura.println(
                    "<tr bgcolor= #246355   >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" //#008080

                    + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>"
                    + "</tr>" + "</B>");

            for (int i = 0; i < tokens.size(); i++) {

                if (i % 2 == 0) {
                    escritura.println(
                            "<tr bgcolor=#ddd      >"
                            + "<td   >" + (i + 1) //#87CEFA
                            + "</td>" + "<td   >" + tokens.get(i).palabra
                            + "</td>" + "<td    >" + (tokens.get(i).Fila + 1)
                            + "</td>" + "<td    >" + (tokens.get(i).Columna + 1)
                            + "</td>" + "<td    >" + (tokens.get(i).Descripcion)
                            + "</td>" + "</tr>"
                    );

                } else {

                    escritura.println(
                            "<tr bgcolor=#F5F5F5    >" + "<td>" + (i + 1)
                            + "</td>" + "<td  >" + tokens.get(i).palabra
                            + "</td>" + "<td   >" + (tokens.get(i).Fila + 1)
                            + "</td>" + "<td   >" + (tokens.get(i).Columna + 1)
                            + "</td>" + "<td    >" + (tokens.get(i).Descripcion)
                            + "</td>" + "</tr>"
                    );
                }

            }
            escritura.println("</table>" + "</center>");
            escritura.println("</body>");
            escritura.println("</html>");

//nos aseguramos de cerrar el archivo
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void GenerarReportesErroresLexicos() {
        try {
            FileWriter archivo = new FileWriter("C:\\Users\\Tomas\\OneDrive\\Documentos\\NetBeansProjects\\[OLC1]Proyecto1_201503783\\src\\Manual\\ReporteErrorLexico.html");
            PrintWriter escritura = new PrintWriter(archivo);
            //escribimos un archivo de texto con la estructura de html
            escritura.println("<html>");
            escritura.println(" <head>");
            escritura.println("<title> Reportes2 </title>");   // "< font color=white>"   D</FONT>
            escritura.println("<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> ");
            escritura.println(" <style type=\"text/css\">\n"
                    + //  " td{background:#ccc;}\n" +
                    " tr:hover td{   background:#369681;     color: white  }\n"
                    + "</style> "
            );

            escritura.println(" <h1><center> <font color= white >  ERRORES LEXICOS </font></center></h1>");
            escritura.println(" </head>");
            escritura.println(" <body  bgcolor= black >");    //#800000
            escritura.println("<center>" + "<table   BORDER = 0  width =100%  bgcolor=white cellspacing=0 cellpadding=10  > ");  //#008080
            escritura.println(
                    "<tr bgcolor= #246355   >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" //#008080
                    + "<td>" + "<B>" + "<font color= white >" + "Tipo" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>"
                    + "</tr>" + "</B>");

            for (int i = 0; i < listaError.size(); i++) {

                if (i % 2 == 0) {
                    escritura.println(
                            "<tr bgcolor=#ddd      >"
                            + "<td   >" + (i + 1) //#87CEFA
                            + "</td>" + "<td>" + listaError.get(i).tipo
                            + "</td>" + "<td>" + listaError.get(i).error
                            + "</td>" + "<td>" + listaError.get(i).linea
                            + "</td>" + "<td>" + listaError.get(i).columna
                            + "</td>" + "<td>" + listaError.get(i).Descripcion + "</td>" + "</tr>"
                    );

                } else {

                    escritura.println(
                            "<tr bgcolor=#F5F5F5    >" + "<td>" + (i + 1)
                            + "</td>" + "<td>" + listaError.get(i).tipo
                            + "</td>" + "<td>" + listaError.get(i).error
                            + "</td>" + "<td>" + listaError.get(i).linea
                            + "</td>" + "<td>" + listaError.get(i).columna
                            + "</td>" + "<td>" + listaError.get(i).Descripcion + "</td>" + "</tr>"
                    );
                }

            }
            escritura.println("</table>" + "</center>");
            escritura.println("</body>");
            escritura.println("</html>");

//nos aseguramos de cerrar el archivo
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void GenerarReportesErroresSintacticos() {

        try {
            FileWriter archivo = new FileWriter("C:\\Users\\Tomas\\OneDrive\\Documentos\\NetBeansProjects\\[OLC1]Proyecto1_201503783\\src\\Manual\\ReporteErrorSintactico.html");
            PrintWriter escritura = new PrintWriter(archivo);
            //escribimos un archivo de texto con la estructura de html
            escritura.println("<html>");
            escritura.println(" <head>");
            escritura.println("<title> Reportes3 </title>");   // "< font color=white>"   D</FONT>
            escritura.println("<font color= white > " + "Fecha y Hora: " + FechaActual() + "</font> ");
            escritura.println(" <style type=\"text/css\">\n"
                    + //  " td{background:#ccc;}\n" +
                    " tr:hover td{   background:#1c1c1c;     color: white  }\n"
                    + "</style> "
            );
//#369681
            escritura.println(" <h1><center> <font color= white > ERRORES SINTACTICOS  </font></center></h1>");
            escritura.println(" </head>");
            escritura.println(" <body  bgcolor= #632432 >");    //#800000
            escritura.println("<center>" + "<table   BORDER = 0  width =100%  bgcolor=white cellspacing=0 cellpadding=10  > ");  //#008080
            escritura.println(
                    "<tr bgcolor= black >" + "<td>" + "<B>" + "<font color= white >" + "No" + "</font>" + "</B>" + "</td>" //#008080

                    + "<td>" + "<B>" + "<font color= white >" + "Tipo" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Lexema" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Linea" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Columna" + "</font>" + "</B>" + "</td>"
                    + "<td>" + "<B>" + "<font color= white >" + "Descripcion" + "</font>" + "</B>" + "</td>"
                    + "</tr>" + "</B>");

            for (int i = 0; i < ErrorSintactico.size(); i++) {

                if (i % 2 == 0) {
                    escritura.println(
                            "<tr bgcolor=#ddd      >"
                            + "<td   >" + (i + 1) //#87CEFA
                            + "</td>" + "<td>" + ErrorSintactico.get(i).tipo
                            + "</td>" + "<td>" + ErrorSintactico.get(i).error
                            + "</td>" + "<td>" + ErrorSintactico.get(i).linea
                            + "</td>" + "<td>" + ErrorSintactico.get(i).columna
                            + "</td>" + "<td>" + ErrorSintactico.get(i).Descripcion + "</td>" + "</tr>"
                    );

                } else {

                    escritura.println(
                            "<tr bgcolor=#F5F5F5    >" + "<td>" + (i + 1)
                            + "</td>" + "<td>" + ErrorSintactico.get(i).tipo
                            + "</td>" + "<td>" + ErrorSintactico.get(i).error
                            + "</td>" + "<td>" + ErrorSintactico.get(i).linea
                            + "</td>" + "<td>" + ErrorSintactico.get(i).columna
                            + "</td>" + "<td>" + ErrorSintactico.get(i).Descripcion + "</td>" + "</tr>"
                    );
                }

            }
            escritura.println("</table>" + "</center>");
            escritura.println("</body>");
            escritura.println("</html>");

//nos aseguramos de cerrar el archivo
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void PaginaWebResultante() {

        try {
            FileWriter archivo = new FileWriter("C:\\Users\\Tomas\\OneDrive\\Documentos\\NetBeansProjects\\[OLC1]Proyecto1_201503783\\src\\Manual\\PaginaResultante.html");
            PrintWriter escritura = new PrintWriter(archivo);
            escritura.println(ContenidoHTML.get(0));
            archivo.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
