/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author Tomas
 */
public class AlmacenarVariables {
 public String id ;
 public String Tipo;
 public Object Valor;
 public int Linea;
 public int Columna;
 String a="a"+'"'+'"';
       public AlmacenarVariables(String id,String Tipo, Object Valor, int Linea,int Columna)
       {
         this.id = id;
         this.Tipo = Tipo;
         this.Valor = Valor;
         this.Linea = Linea;
         this.Columna = Columna;
   
       }
 
 
    
    
    
    
}
