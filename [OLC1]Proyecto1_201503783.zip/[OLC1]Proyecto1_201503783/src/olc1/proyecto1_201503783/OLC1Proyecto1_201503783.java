/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package olc1.proyecto1_201503783;

import static FaseCompilador.GeneradorCompilador.generarcompiladores;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JFrame;
import org.jvnet.substance.SubstanceLookAndFeel;
/**
 *
 * @author Tomas
 */
public class OLC1Proyecto1_201503783 {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
    
         JFrame.setDefaultLookAndFeelDecorated(true);
         
      // SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.EmeraldDuskSkin");
      // SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.MagmaSkin");
      
      SubstanceLookAndFeel.setSkin("org.jvnet.substance.skin.RavenSkin");
     generarcompiladores();
        
        /*
        try{
        colocarSkin();
        }catch(Exception err){}
      */  
        Compiladores1 c = new Compiladores1();
       
        c.show();
    
    
    }
 
    
    public static void colocarSkin() throws UnsupportedLookAndFeelException{
  try {
   UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
   } catch (ClassNotFoundException e) {
    e.printStackTrace();
   } catch (InstantiationException e) {
    e.printStackTrace();
   } catch (IllegalAccessException e) {
    e.printStackTrace();
   } catch (UnsupportedLookAndFeelException e) {
    e.printStackTrace();
   }
 }
    
    
}
