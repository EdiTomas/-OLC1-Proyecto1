/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Struct;

/**
 *
 * @author Tomas
 */
public class CrearTextoB {

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    private String id;    
    private String contenido;
    
    public CrearTextoB(String id, String contenido){
     this.id = id;    
     this.contenido= contenido;
    
    }
}
