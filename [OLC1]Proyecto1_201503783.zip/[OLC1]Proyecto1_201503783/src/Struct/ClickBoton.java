/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Struct;

/**
 *
 * @author Tomas
 */
public class ClickBoton {
    
    private String id;
    private String Contenido;
  
    public ClickBoton(){}
    
    public ClickBoton(String variable,String Contenido){
     this.id = variable;
     this.Contenido= Contenido;
     
    }

    public String Traducir(){
    String a   = "<script type = \"text/javascript\">"+
		               "$(document).ready(function(){"+
			       "$('#" + getVariable() + "').click(function(){"+
			       "alert("+"\"" + getContenido() + "\""+");"+"});"+"});"+
                               "</script>";
    return a;
    }   
    
    
    public String getVariable() {
        return id;
    }

    public void setVariable(String variable) {
        this.id = variable;
    }

    public String getContenido() {
        return Contenido;
    }

    public void setContenido(String Contenido) {
        this.Contenido = Contenido;
    }
    
    
    
    
}
