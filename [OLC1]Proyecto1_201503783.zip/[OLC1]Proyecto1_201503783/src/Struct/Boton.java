/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Struct;

/**
 *
 * @author Tomas
 */
public class Boton {
 
    
 private  String Variable;
 private String Id;
 private String alerta;
 private String texto;
 
 public Boton(String Variable, String Id, String texto){
    this.Variable= Variable;
    this.Id =Id;
    this.alerta = "";
    this.texto = texto;   
 }

    public String getVariable() {
        return Variable;
    }

    public void setVariable(String Variable) {
        this.Variable = Variable;
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getAlerta() {
        return alerta;
    }

    public void setAlerta(String alerta) {
        this.alerta = alerta;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
 
 
 
}
