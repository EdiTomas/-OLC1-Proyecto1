/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Struct;

/**
 *
 * @author Tomas
 */
public class CrearTextoA {
    
    private String id;    
    private String contenido;
    
    public CrearTextoA(String id, String contenido){
     this.id = id;    
     this.contenido= contenido;
    
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    
    
    
}
