/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Struct;

/**
 *
 * @author Tomas
 */
public class CrearImagenes {
    private String id;
    private String ruta;
    private String Ancho;
    private String Alto;
    
    public CrearImagenes(String id,String ruta,String  Ancho,String Alto)
    {
      this.id = id;  
      this.ruta = ruta;    
      this.Ancho = Ancho;
      this.Alto= Alto;
   
    }
    
    public CrearImagenes(String id,String ruta)
    {
      this.id = id;  
      this.ruta = ruta;    
      this.Ancho = "";
      this.Alto= "";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRuta() {
        return ruta;
    }

    public void setRuta(String ruta) {
        this.ruta = ruta;
    }

    public String getAncho() {
        return Ancho;
    }

    public void setAncho(String Ancho) {
        this.Ancho = Ancho;
    }

    public String getAlto() {
        return Alto;
    }

    public void setAlto(String Alto) {
        this.Alto = Alto;
    }
    
    
    
    
}
